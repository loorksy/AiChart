# ربط AiChart MCP مع Claude.ai Connectors

## أين تضع عنوان MCP

**المسار:** [claude.ai/customize/connectors](https://claude.ai/customize/connectors) → **Add custom connector** (BETA)

| حقل الواجهة | القيمة |
|-------------|--------|
| **Name** | `AiChart Trading` |
| **Remote MCP server URL** | `https://aichart.lork.cloud/mcp` |
| **OAuth Client ID** (Advanced) | فارغ |
| **OAuth Client Secret** (Advanced) | فارغ |

### لا تضع في URL

- لا `AICHART_SERVICE_TOKEN`
- لا `?token=` في الرابط
- لا `/api/agent/…` — Claude يتصل بـ MCP Server فقط

---

## 1) تجهيز VPS

### متغيرات في `web/.env`

```env
AICHART_SERVICE_TOKEN=...          # موجود مسبقاً
MCP_AUTH_SECRET=...                # openssl rand -hex 32
MCP_PUBLIC_URL=https://aichart.lork.cloud/mcp
MCP_PORT=8787
MCP_AUTH_MODE=oauth
MCP_ACCESS_TOKEN_TTL_DAYS=365
MCP_REFRESH_TOKEN_TTL_DAYS=365
```

`MCP_AUTH_SECRET` **نفس القيمة** على عملية MCP وفي web (لـ `/api/admin/mcp-auth/verify`).

### مصادقة ثابتة (v2)

- **Access token:** JWT موقّع — صالح **365 يوم** — يبقى بعد `pm2 restart aichart-mcp`
- **Refresh token:** مخزّن في SQLite — Claude يجدّد تلقائياً
- **OAuth clients:** مخزّنة في SQLite — لا تُفقد عند restart

بعد ترقية MCP لأول مرة: **أعد OAuth في Claude مرة واحدة** (التوكنات القديمة UUID لم تعد صالحة).

### نشر MCP

```bash
cd /opt/aichart
bash infra/vps-mcp-deploy.sh
```

### nginx

أضف محتوى [`infra/nginx/aichart-mcp.conf`](../infra/nginx/aichart-mcp.conf) داخل vhost `aichart.lork.cloud`:

```bash
sudo nginx -t && sudo systemctl reload nginx
```

### تحقق

```bash
curl -s https://aichart.lork.cloud/health
curl -sI https://aichart.lork.cloud/.well-known/oauth-protected-resource
```

---

## 2) ربط Claude

1. Customize → Connectors → Add custom connector
2. URL: `https://aichart.lork.cloud/mcp`
3. Add → يفتح OAuth → سجّل admin AiChart
4. بعد الموافقة تظهر أدوات التداول في الشات

---

## 3) أمثلة prompts

```
تحقق من get_risk_status ثم حلّل BTCUSDT على 1h
```

```
ورّيني الصفقات المفتوحة والرصيد
```

```
سجّل توصية sell على ETHUSDT بثقة 80% مع SL و TP
```

```
افتح صفقة demo على BTCUSDT — approved_by_user: true بعد موافقتي
```

---

## 4) تعليمات Claude (Project)

> قبل أي صفقة: `get_risk_status`. قبل رأي فني: `get_market_snapshot`.  
> Risk Guard يرفض تجاوز الحدود — انقل السبب حرفياً.  
> في وضع approval: اطلب موافقة صريحة قبل `open_trade`.  
> اقرأ resource `aichart://trading-rules` عند الحاجة.

---

## 5) إيقاف OpenClaw (اختياري)

راجع [`OPENCLAW_DECOMMISSION.md`](OPENCLAW_DECOMMISSION.md).

---

## استكشاف الأخطاء

| العرض | الحل |
|-------|------|
| Add معطّل / فشل الاتصال | تحقق `curl /health` و nginx `/mcp` |
| OAuth loop | امسح cookies `aichart_mcp_session` |
| 401 على الأدوات | أعد ربط Connector (مرة واحدة بعد ترقية JWT) |
| أدوات تفشل بعد restart | يجب ألا يحدث — JWT ثابت؛ تحقق `pm2 logs aichart-mcp` |
| Bridge 503 | `AICHART_SERVICE_TOKEN` في web + MCP |
| login فاشل | `MCP_AUTH_SECRET` متطابق؛ حساب admin |
