#!/usr/bin/env bash
# Smoke test: mint JWT, verify after pm2 restart simulation.
set -euo pipefail
source /opt/aichart/web/.env
cd /opt/aichart/mcp
node --input-type=module <<'NODE'
import { mintAccessToken, verifyAccessTokenJwt } from './dist/auth/jwt.js';
const secret = process.env.MCP_AUTH_SECRET;
const { token } = await mintAccessToken(secret, {
  email: 'test@example.com',
  clientId: 'test-client',
  scopes: ['mcp:tools'],
}, 365);
const info = await verifyAccessTokenJwt(secret, token);
console.log('JWT OK', info.clientId, info.extra?.email);
NODE
echo "Tables:"
sqlite3 "$(grep DB_PATH /opt/aichart/web/.env 2>/dev/null | cut -d= -f2- | tr -d '\r' | sed 's|^|/opt/aichart/web/|' | head -1 || echo /opt/aichart/web/data/aichart.db)" ".tables" 2>/dev/null | grep mcp_oauth || echo "check db path manually"
curl -sS https://aichart.lork.cloud/health
