import { readFileSync } from "node:fs";
import { join } from "node:path";
import type { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { z } from "zod";
import {
  BridgeClient,
  formatBridgeError,
  formatBridgeResult,
} from "../bridge/client.js";

function tradingRulesText(): string {
  const candidates = [
    join(process.cwd(), "../agent/workspace/AGENTS.md"),
    join(process.cwd(), "agent/workspace/AGENTS.md"),
  ];
  for (const path of candidates) {
    try {
      const raw = readFileSync(path, "utf8");
      return raw.length > 12000 ? `${raw.slice(0, 12000)}\n…(مختصر)` : raw;
    } catch {
      /* try next */
    }
  }
  return "قواعد AiChart: تحقق من get_risk_status قبل أي صفقة. Risk Guard يرفض تجاوز الحدود.";
}

export function registerAiChartTools(server: McpServer, bridge: BridgeClient) {
  server.registerResource(
    "trading-rules",
    "aichart://trading-rules",
    {
      title: "AiChart Trading Rules",
      description: "قواعد التشغيل والتداول للمشغّل",
      mimeType: "text/markdown",
    },
    async () => ({
      contents: [
        {
          uri: "aichart://trading-rules",
          mimeType: "text/markdown",
          text: tradingRulesText(),
        },
      ],
    }),
  );

  const wrap =
    (fn: () => Promise<unknown>) =>
    async () => {
      try {
        return formatBridgeResult(await fn());
      } catch (e) {
        return formatBridgeError(e);
      }
    };

  server.registerTool(
    "get_risk_status",
    {
      description:
        "حالة المخاطر والوضع (auto/approval/direct)، kill switch، حدود رأس المال، executionEnv.",
      inputSchema: {},
    },
    wrap(() => bridge.get("/api/agent/risk/status")),
  );

  server.registerTool(
    "get_market_snapshot",
    {
      description: "لقطة فنية حية: سعر، RSI، MACD، SMA، اتجاه.",
      inputSchema: {
        symbol: z.string().describe("مثل BTCUSDT"),
        interval: z.string().optional().describe("1h, 4h, 1d…"),
        market: z.enum(["crypto", "forex"]).optional(),
      },
    },
    async ({ symbol, interval, market }) => {
      try {
        return formatBridgeResult(
          await bridge.get("/api/agent/market/snapshot", {
            symbol,
            interval,
            market,
          }),
        );
      } catch (e) {
        return formatBridgeError(e);
      }
    },
  );

  server.registerTool(
    "get_market_price",
    {
      description: "السعر اللحظي لزوج.",
      inputSchema: {
        symbol: z.string(),
        market: z.enum(["crypto", "forex"]).optional(),
      },
    },
    async ({ symbol, market }) => {
      try {
        return formatBridgeResult(
          await bridge.get("/api/agent/market/price", { symbol, market }),
        );
      } catch (e) {
        return formatBridgeError(e);
      }
    },
  );

  server.registerTool(
    "get_market_context",
    {
      description: "سياق السوق: أخبار، fear & greed، مزاج.",
      inputSchema: {
        symbol: z.string(),
        interval: z.string().optional(),
      },
    },
    async ({ symbol, interval }) => {
      try {
        return formatBridgeResult(
          await bridge.get("/api/agent/market/context", { symbol, interval }),
        );
      } catch (e) {
        return formatBridgeError(e);
      }
    },
  );

  server.registerTool(
    "scan_market",
    {
      description: "مسح فرص فنية على قائمة رموز (كود فقط، بدون AI).",
      inputSchema: {
        symbols: z.array(z.string()).max(30).optional(),
        interval: z.string().optional(),
        market: z.enum(["crypto", "forex"]).optional(),
      },
    },
    async (body) => {
      try {
        return formatBridgeResult(
          await bridge.post("/api/agent/market/scan", body),
        );
      } catch (e) {
        return formatBridgeError(e);
      }
    },
  );

  server.registerTool(
    "get_portfolio",
    {
      description: "محفظة المشغّل: رصيد، PnL، ملخص.",
      inputSchema: {},
    },
    wrap(() => bridge.get("/api/agent/portfolio")),
  );

  server.registerTool(
    "get_open_trades",
    {
      description: "الصفقات المفتوحة + summary_ar.",
      inputSchema: {},
    },
    wrap(() => bridge.get("/api/agent/trades/open")),
  );

  server.registerTool(
    "get_trade_lessons",
    {
      description: "دروس مشابهة من الذاكرة بعد صفقات سابقة.",
      inputSchema: {
        symbol: z.string().optional(),
        pattern: z.string().optional(),
        limit: z.number().int().min(1).max(10).optional(),
      },
    },
    async ({ symbol, pattern, limit }) => {
      try {
        return formatBridgeResult(
          await bridge.get("/api/agent/memory/lessons", {
            symbol,
            pattern,
            limit,
          }),
        );
      } catch (e) {
        return formatBridgeError(e);
      }
    },
  );

  server.registerTool(
    "create_recommendation",
    {
      description: "تسجيل توصية منظمة مع شارت (chart_drawings اختياري).",
      inputSchema: {
        symbol: z.string(),
        action: z.enum(["buy", "sell", "wait"]),
        confidence: z.number().min(0).max(100),
        rationale: z.string(),
        factors: z.array(z.string()).min(1).max(8),
        entry: z.number().optional(),
        stop_loss: z.number().optional(),
        take_profit: z.number().optional(),
        timeframe: z.string().optional(),
        pattern_name: z.string().optional(),
        chart_drawings: z.array(z.record(z.string(), z.unknown())).optional(),
      },
    },
    async (body) => {
      try {
        return formatBridgeResult(
          await bridge.post("/api/agent/recommendation", body),
        );
      } catch (e) {
        return formatBridgeError(e);
      }
    },
  );

  server.registerTool(
    "open_trade",
    {
      description:
        "فتح صفقة عبر Risk Guard. approved_by_user:true عند موافقة صريحة من المشغّل.",
      inputSchema: {
        symbol: z.string(),
        side: z.enum(["buy", "sell"]),
        notional: z.number().positive().optional(),
        market: z.enum(["crypto", "forex"]).optional(),
        entry: z.number().optional(),
        stop_loss: z.number().optional(),
        take_profit: z.number().optional(),
        confidence: z.number().min(0).max(100).optional(),
        rationale: z.string().optional(),
        recommendation_id: z.number().optional(),
        approved_by_user: z.boolean().optional(),
        practice: z.boolean().optional(),
        market_type: z.enum(["spot", "futures"]).optional(),
        leverage: z.number().min(1).max(125).optional(),
        order_type: z.enum(["market", "limit"]).optional(),
        limit_price: z.number().positive().optional(),
      },
    },
    async (body) => {
      try {
        return formatBridgeResult(
          await bridge.post("/api/agent/trade/open", body),
        );
      } catch (e) {
        return formatBridgeError(e);
      }
    },
  );

  server.registerTool(
    "close_trade",
    {
      description: "إغلاق صفقة واحدة أو كل الصفقات.",
      inputSchema: {
        trade_id: z.number().int().positive().optional(),
        all: z.boolean().optional(),
      },
    },
    async (body) => {
      try {
        return formatBridgeResult(
          await bridge.post("/api/agent/trade/close", body),
        );
      } catch (e) {
        return formatBridgeError(e);
      }
    },
  );

  server.registerTool(
    "evaluate_trade",
    {
      description: "تقييم صفقة مفتوحة: سعر حي، شموع، PnL، سياق.",
      inputSchema: {
        trade_id: z.number().int().positive(),
      },
    },
    async ({ trade_id }) => {
      try {
        return formatBridgeResult(
          await bridge.get("/api/agent/trade/evaluate", { trade_id }),
        );
      } catch (e) {
        return formatBridgeError(e);
      }
    },
  );

  server.registerTool(
    "record_exit_decision",
    {
      description: "تسجيل قرار hold/close/adjust_sl (audit).",
      inputSchema: {
        trade_id: z.number().int().positive(),
        decision: z.enum(["hold", "close", "adjust_sl"]),
        reason: z.string().min(3).max(500),
        new_stop_loss: z.number().positive().optional(),
      },
    },
    async (body) => {
      try {
        return formatBridgeResult(
          await bridge.post("/api/agent/trade/exit-decision", body),
        );
      } catch (e) {
        return formatBridgeError(e);
      }
    },
  );

  server.registerTool(
    "request_approval",
    {
      description: "طلب موافقة على صفقة (أزرار تيليجرام إن وُجد ربط).",
      inputSchema: {
        symbol: z.string(),
        side: z.enum(["buy", "sell"]),
        notional: z.number().positive().optional(),
        market: z.enum(["crypto", "forex"]).optional(),
        entry: z.number().optional(),
        stop_loss: z.number().optional(),
        take_profit: z.number().optional(),
        confidence: z.number().min(0).max(100).optional(),
        rationale: z.string().optional(),
        recommendation_id: z.number().optional(),
        practice: z.boolean().optional(),
      },
    },
    async (body) => {
      try {
        return formatBridgeResult(
          await bridge.post("/api/agent/approval/request", body),
        );
      } catch (e) {
        return formatBridgeError(e);
      }
    },
  );

  server.registerTool(
    "respond_approval",
    {
      description: "الموافقة أو الرفض على intent معلّق.",
      inputSchema: {
        intent_id: z.number().int().positive(),
        action: z.enum(["approve", "reject"]),
      },
    },
    async (body) => {
      try {
        return formatBridgeResult(
          await bridge.post("/api/agent/approval/respond", body),
        );
      } catch (e) {
        return formatBridgeError(e);
      }
    },
  );

  server.registerTool(
    "get_execution_env",
    {
      description: "بيئة التنفيذ demo/live وBinance/MT5.",
      inputSchema: {},
    },
    wrap(() => bridge.get("/api/agent/execution/env")),
  );

  server.registerTool(
    "set_execution_env",
    {
      description: "تبديل demo ↔ live.",
      inputSchema: {
        preference: z.enum(["demo", "live"]),
      },
    },
    async ({ preference }) => {
      try {
        return formatBridgeResult(
          await bridge.post("/api/agent/execution/env", { preference }),
        );
      } catch (e) {
        return formatBridgeError(e);
      }
    },
  );

  server.registerTool(
    "set_trading_mode",
    {
      description: "تبديل وضع التداول: auto | approval | direct.",
      inputSchema: {
        mode: z.enum(["auto", "approval", "direct"]),
      },
    },
    async ({ mode }) => {
      try {
        return formatBridgeResult(
          await bridge.post("/api/agent/mode", { mode }),
        );
      } catch (e) {
        return formatBridgeError(e);
      }
    },
  );

  server.registerTool(
    "set_kill_switch",
    {
      description: "تفعيل/إيقاف kill switch (user أو master).",
      inputSchema: {
        on: z.boolean(),
        scope: z.enum(["user", "master"]).optional(),
        close_open_trades: z.boolean().optional(),
      },
    },
    async (body) => {
      try {
        return formatBridgeResult(
          await bridge.post("/api/agent/kill-switch", {
            scope: body.scope ?? "user",
            close_open_trades: body.close_open_trades ?? false,
            on: body.on,
          }),
        );
      } catch (e) {
        return formatBridgeError(e);
      }
    },
  );
}
