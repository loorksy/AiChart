# Graph Report - src  (2026-06-17)

## Corpus Check
- 398 files · ~136,664 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 1925 nodes · 7261 edges · 86 communities (83 shown, 3 thin omitted)
- Extraction: 96% EXTRACTED · 4% INFERRED · 0% AMBIGUOUS · INFERRED: 305 edges (avg confidence: 0.8)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `77bb9802`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- [[_COMMUNITY_Community 0|Community 0]]
- [[_COMMUNITY_Community 1|Community 1]]
- [[_COMMUNITY_Community 2|Community 2]]
- [[_COMMUNITY_Community 3|Community 3]]
- [[_COMMUNITY_Community 4|Community 4]]
- [[_COMMUNITY_Community 5|Community 5]]
- [[_COMMUNITY_Community 6|Community 6]]
- [[_COMMUNITY_Community 7|Community 7]]
- [[_COMMUNITY_Community 8|Community 8]]
- [[_COMMUNITY_Community 9|Community 9]]
- [[_COMMUNITY_Community 10|Community 10]]
- [[_COMMUNITY_Community 11|Community 11]]
- [[_COMMUNITY_Community 12|Community 12]]
- [[_COMMUNITY_Community 13|Community 13]]
- [[_COMMUNITY_Community 14|Community 14]]
- [[_COMMUNITY_Community 15|Community 15]]
- [[_COMMUNITY_Community 16|Community 16]]
- [[_COMMUNITY_Community 17|Community 17]]
- [[_COMMUNITY_Community 18|Community 18]]
- [[_COMMUNITY_Community 19|Community 19]]
- [[_COMMUNITY_Community 20|Community 20]]
- [[_COMMUNITY_Community 21|Community 21]]
- [[_COMMUNITY_Community 22|Community 22]]
- [[_COMMUNITY_Community 23|Community 23]]
- [[_COMMUNITY_Community 24|Community 24]]
- [[_COMMUNITY_Community 25|Community 25]]
- [[_COMMUNITY_Community 26|Community 26]]
- [[_COMMUNITY_Community 27|Community 27]]
- [[_COMMUNITY_Community 28|Community 28]]
- [[_COMMUNITY_Community 29|Community 29]]
- [[_COMMUNITY_Community 30|Community 30]]
- [[_COMMUNITY_Community 31|Community 31]]
- [[_COMMUNITY_Community 32|Community 32]]
- [[_COMMUNITY_Community 33|Community 33]]
- [[_COMMUNITY_Community 34|Community 34]]
- [[_COMMUNITY_Community 35|Community 35]]
- [[_COMMUNITY_Community 36|Community 36]]
- [[_COMMUNITY_Community 37|Community 37]]
- [[_COMMUNITY_Community 38|Community 38]]
- [[_COMMUNITY_Community 39|Community 39]]
- [[_COMMUNITY_Community 40|Community 40]]
- [[_COMMUNITY_Community 41|Community 41]]
- [[_COMMUNITY_Community 42|Community 42]]
- [[_COMMUNITY_Community 43|Community 43]]
- [[_COMMUNITY_Community 44|Community 44]]
- [[_COMMUNITY_Community 45|Community 45]]
- [[_COMMUNITY_Community 47|Community 47]]
- [[_COMMUNITY_Community 49|Community 49]]
- [[_COMMUNITY_Community 50|Community 50]]
- [[_COMMUNITY_Community 51|Community 51]]
- [[_COMMUNITY_Community 52|Community 52]]
- [[_COMMUNITY_Community 53|Community 53]]
- [[_COMMUNITY_Community 54|Community 54]]
- [[_COMMUNITY_Community 55|Community 55]]
- [[_COMMUNITY_Community 56|Community 56]]
- [[_COMMUNITY_Community 57|Community 57]]
- [[_COMMUNITY_Community 58|Community 58]]
- [[_COMMUNITY_Community 59|Community 59]]
- [[_COMMUNITY_Community 60|Community 60]]
- [[_COMMUNITY_Community 61|Community 61]]
- [[_COMMUNITY_Community 62|Community 62]]
- [[_COMMUNITY_Community 63|Community 63]]
- [[_COMMUNITY_Community 64|Community 64]]
- [[_COMMUNITY_Community 65|Community 65]]
- [[_COMMUNITY_Community 66|Community 66]]
- [[_COMMUNITY_Community 67|Community 67]]
- [[_COMMUNITY_Community 68|Community 68]]
- [[_COMMUNITY_Community 69|Community 69]]
- [[_COMMUNITY_Community 70|Community 70]]
- [[_COMMUNITY_Community 71|Community 71]]
- [[_COMMUNITY_Community 72|Community 72]]
- [[_COMMUNITY_Community 73|Community 73]]
- [[_COMMUNITY_Community 74|Community 74]]
- [[_COMMUNITY_Community 75|Community 75]]
- [[_COMMUNITY_Community 76|Community 76]]
- [[_COMMUNITY_Community 77|Community 77]]
- [[_COMMUNITY_Community 78|Community 78]]
- [[_COMMUNITY_Community 79|Community 79]]
- [[_COMMUNITY_Community 80|Community 80]]
- [[_COMMUNITY_Community 81|Community 81]]
- [[_COMMUNITY_Community 82|Community 82]]
- [[_COMMUNITY_Community 83|Community 83]]
- [[_COMMUNITY_Community 84|Community 84]]
- [[_COMMUNITY_Community 85|Community 85]]

## God Nodes (most connected - your core abstractions)
1. `handleError()` - 235 edges
2. `cn()` - 116 edges
3. `requireAgentAuth()` - 100 edges
4. `getSettings()` - 100 edges
5. `requireUser()` - 95 edges
6. `resolveAgentUserId()` - 90 edges
7. `execute()` - 57 edges
8. `logAudit()` - 56 edges
9. `getCurrentUser()` - 51 edges
10. `getLimits()` - 46 edges

## Surprising Connections (you probably didn't know these)
- `AgentConsoleRedirect()` --calls--> `getCurrentUser()`  [INFERRED]
  app/agent/console/page.tsx → lib/auth.ts
- `AgentRedirect()` --calls--> `getCurrentUser()`  [EXTRACTED]
  app/agent/page.tsx → lib/auth.ts
- `GET()` --calls--> `handleError()`  [INFERRED]
  app/api/admin/binance-capture/route.ts → lib/api.ts
- `GET()` --calls--> `requireAdmin()`  [INFERRED]
  app/api/admin/binance-capture/route.ts → lib/api.ts
- `POST()` --calls--> `handleError()`  [INFERRED]
  app/api/admin/binance-capture/route.ts → lib/api.ts

## Import Cycles
- 3-file cycle: `lib/db.ts -> lib/db/index.ts -> lib/env.ts -> lib/db.ts`
- 4-file cycle: `lib/db.ts -> lib/db/index.ts -> lib/db/sqlite.ts -> lib/env.ts -> lib/db.ts`

## Communities (86 total, 3 thin omitted)

### Community 0 - "Community 0"
Cohesion: 0.13
Nodes (29): GET(), htmlPage(), GET(), schema, getBrokerAdapter(), POST(), requireActiveUser(), respondToApproval() (+21 more)

### Community 1 - "Community 1"
Cohesion: 0.14
Nodes (9): CommitteeFeed(), HeatmapCell, HeatmapGrid(), MemoryHighlights(), FlowSignal, WhaleBubbles(), CommitteeResult, TradeLesson (+1 more)

### Community 2 - "Community 2"
Cohesion: 0.18
Nodes (24): debugSessionLog(), clearTelegramChatId(), createLinkCode(), getTelegramChatId(), call(), executedCard(), getBotUsername(), isTelegramConfigured() (+16 more)

### Community 3 - "Community 3"
Cohesion: 0.29
Nodes (13): committeeSummaryTelegram(), defaultVote(), evaluateCommittee(), extractText(), parseCommitteeJson(), attachChartToRecommendation(), saveRecommendation(), updateRecommendationChartUrl() (+5 more)

### Community 4 - "Community 4"
Cohesion: 0.08
Nodes (30): ForexBackendMode, ALERT_TYPE_LABEL, AlertsCard(), SettingsClient(), TabId, TABS, useTheme(), ForexConnectionView (+22 more)

### Community 5 - "Community 5"
Cohesion: 0.18
Nodes (13): GET(), AgentModelStatus, buildFallbackRefs(), CROSS_FALLBACK_CANDIDATES, FALLBACK_PROVIDER_ORDER, getAgentModelStatus(), isAllowedModelRef(), PROVIDER_BASE_URL (+5 more)

### Community 6 - "Community 6"
Cohesion: 0.18
Nodes (21): DELETE(), GET(), PATCH(), createSchema, GET(), POST(), execute(), Params (+13 more)

### Community 7 - "Community 7"
Cohesion: 0.11
Nodes (34): AnthropicModelInfo, AnthropicResponse, buildSystemBlocks(), CacheControl, cachedMessages(), cachedTools(), callAnthropic(), callAnthropicStream() (+26 more)

### Community 8 - "Community 8"
Cohesion: 0.15
Nodes (26): POST(), schema, POST(), schema, GET(), POST(), GET(), ApiRestrictions (+18 more)

### Community 9 - "Community 9"
Cohesion: 0.09
Nodes (28): ChatClient(), ChatMessage, MessageBubble(), RecCard(), STATUS_AR, STATUS_CLASS, TradesClient(), PendingIntentQuickActions() (+20 more)

### Community 10 - "Community 10"
Cohesion: 0.11
Nodes (28): arcPath(), AssetDistributionChart(), polarToCartesian(), SLICE_COLORS, InteractivePerformanceChart(), PeriodSelector(), ReportsClient(), DashboardAnalytics() (+20 more)

### Community 11 - "Community 11"
Cohesion: 0.67
Nodes (4): allowedAssetsLabel(), buildSystemPrompt(), SystemPromptParts, buildUserContext()

### Community 12 - "Community 12"
Cohesion: 0.14
Nodes (21): initialCountry(), LABELS, PhoneInput(), PRIORITY, TelegramLoginButton(), GET(), isSingleUserMode(), countryFromAcceptLanguage() (+13 more)

### Community 13 - "Community 13"
Cohesion: 0.14
Nodes (30): GET(), BinanceEnv, FuturesPosition, buildConsoleActiveTrades(), loadIntentSlTp(), mapAichartBase(), mapBinanceFuturesRow(), mapMt5Row() (+22 more)

### Community 14 - "Community 14"
Cohesion: 0.15
Nodes (8): AdminOverview(), ActiveTradesTable(), ConnectionStatus, StatusChip(), StatusChipTone, TONE, ConsoleActiveTradeRow, AdminPlatformStats

### Community 15 - "Community 15"
Cohesion: 0.08
Nodes (39): MasterKillCard(), DEFAULT_SYMBOL, Instrument, MarketClient(), OVERLAY_LABELS, PriceChart, PriceChartHandle, Props (+31 more)

### Community 16 - "Community 16"
Cohesion: 0.22
Nodes (18): POST(), GET(), BinanceCaptureConfig, BinanceCaptureMarket, binanceChartUrl(), cacheKey(), getBinanceCaptureConfig(), BinanceCaptureInput (+10 more)

### Community 17 - "Community 17"
Cohesion: 0.10
Nodes (20): botCommands, menuActions, crypto, demo, forex, iadadat, live, qaima (+12 more)

### Community 18 - "Community 18"
Cohesion: 0.13
Nodes (34): accountFooterLines(), AccountProfile, accountTypeAr(), buildAccountProfile(), platformLabel(), appBaseUrl(), ApprovalKind, buildApprovalButtonsForIntent() (+26 more)

### Community 19 - "Community 19"
Cohesion: 0.11
Nodes (17): AgentRedirect(), BEGINNER_STEPS, EXPERT_STEPS, AgentStatus, AgentStatusBar(), MODE_LABEL, pulseState(), TradingMode (+9 more)

### Community 20 - "Community 20"
Cohesion: 0.27
Nodes (14): GET(), livePrice(), get24hStats(), isHeartbeatFresh(), parseTimestamp(), ema(), macd(), MacdResult (+6 more)

### Community 21 - "Community 21"
Cohesion: 0.10
Nodes (41): DELETE(), DELETE(), POST(), GET(), GET(), POST(), schema, drawingSchema (+33 more)

### Community 22 - "Community 22"
Cohesion: 0.13
Nodes (15): ConsoleAccountPage(), AdminLayout(), ChatRedirect(), CommandRedirect(), AgentConsoleRedirect(), clearSession(), createSessionToken(), getCurrentUser() (+7 more)

### Community 23 - "Community 23"
Cohesion: 0.15
Nodes (15): AgentPlanMode, ANALYSIS_PLAN_TEMPLATE, applyProgress(), cloneTasks(), flattenSubtaskKeys(), getPlanTemplate(), PlanStatus, PlanSubtask (+7 more)

### Community 24 - "Community 24"
Cohesion: 0.17
Nodes (27): POST(), schema, imageSchema, POST(), schema, POST(), rawSchema, schema (+19 more)

### Community 25 - "Community 25"
Cohesion: 0.07
Nodes (61): POST(), GET(), forexBrokerKind(), getForexBackend(), ConsoleConnectPage(), GET(), eaForexInstruments(), GET() (+53 more)

### Community 26 - "Community 26"
Cohesion: 0.20
Nodes (24): GET(), GET(), deliverSignal(), DeliveryGateResult, DeliveryReason, DeliveryResult, dispatchAlert(), DispatchAlertOptions (+16 more)

### Community 27 - "Community 27"
Cohesion: 0.20
Nodes (17): insertReturningId(), queryOne(), pgQueryOne(), hashPassword(), DEFAULT_COUNTRY, normalizeWhatsApp(), ensureUserDefaults(), getPublicUser() (+9 more)

### Community 28 - "Community 28"
Cohesion: 0.22
Nodes (21): GET(), GET(), modelRefFromPlatform(), getAnthropicModel(), listAnthropicModels(), getPublicAppUrl(), compatTarget(), getActiveModel() (+13 more)

### Community 29 - "Community 29"
Cohesion: 0.17
Nodes (11): AdminUsersTable(), formatExpiry(), formatExpiryCell(), TableMode, accessDaysRemaining(), formatAccessRemaining(), AdminUserView, listUsersForAdmin() (+3 more)

### Community 30 - "Community 30"
Cohesion: 0.11
Nodes (27): applyChartDrawings(), ApplyDrawingsResult, collectDrawingMarkers(), FIB_RATIOS, fibLevels(), markerShape(), numMeta(), pointArrMeta() (+19 more)

### Community 31 - "Community 31"
Cohesion: 0.12
Nodes (27): POST(), schema, GET(), POST(), schema, HeartbeatBody, POST(), extractBearer() (+19 more)

### Community 32 - "Community 32"
Cohesion: 0.31
Nodes (12): POST(), schema, POST(), schema, eaKillCloseFlagKey(), queueEaCloseAllPositions(), queueEaClosePosition(), completeOnboarding() (+4 more)

### Community 33 - "Community 33"
Cohesion: 0.19
Nodes (11): LandingAccess(), LANDING, LandingCta(), LandingFaq(), LandingFeatures(), LandingFooter(), LandingHero(), LandingHowItWorks() (+3 more)

### Community 34 - "Community 34"
Cohesion: 0.29
Nodes (9): MacroTicker(), baseAsset(), fetchCryptoPanicHeadlines(), fetchFearGreed(), fetchMarketContext(), fetchSocialHype(), MarketContext, MarketHeadline (+1 more)

### Community 35 - "Community 35"
Cohesion: 0.17
Nodes (19): POST(), schema, isSymbolAllowed(), resolveScanAssets(), MarketSnapshot, OpportunityCandidate, ProximityHit, ProximityKind (+11 more)

### Community 36 - "Community 36"
Cohesion: 0.14
Nodes (23): createEmbedding(), isEmbeddingConfigured(), openAiKey(), synthesizeSpeech(), getPlatformValueAsync(), cosineSimilarity(), filterBySymbolFallback(), insertTradeLesson() (+15 more)

### Community 37 - "Community 37"
Cohesion: 0.10
Nodes (31): DELETE(), GET(), PATCH(), patchSchema, DELETE(), GET(), DELETE(), GET() (+23 more)

### Community 38 - "Community 38"
Cohesion: 0.12
Nodes (20): POST(), schema, AnalysisProfile, AnalysisTier, INTRADAY, POSITION, profileForInterval(), SWING (+12 more)

### Community 39 - "Community 39"
Cohesion: 0.17
Nodes (19): decryptSecret(), encryptSecret(), getKey(), maskKey(), getEncryptionKey(), cache, clearPlatformConfigCache(), ConfigFieldMeta (+11 more)

### Community 40 - "Community 40"
Cohesion: 0.17
Nodes (15): GET(), POST(), schema, POST(), schema, POST(), schema, GET() (+7 more)

### Community 41 - "Community 41"
Cohesion: 0.15
Nodes (18): Home(), AwaitingApprovalPage(), BridgeOverviewClient(), AwaitingApprovalClient(), COPY, ConsoleLayout(), metadata, ConsoleOverviewPage() (+10 more)

### Community 42 - "Community 42"
Cohesion: 0.25
Nodes (13): buildChartImageUrl(), OVERLAY_COLORS, buildChartJson(), buildChartSnapshotBufferForMarket(), buildChartSnapshotUrl(), fetchCandleSeries(), FIB_RATIOS, fibLevels() (+5 more)

### Community 47 - "Community 47"
Cohesion: 0.15
Nodes (26): bootstrapCache, ensureDb(), getBootstrapFromCache(), getDbBackend(), getDbInfo(), initDb(), isPostgresReady(), loadPlatformConfigRows() (+18 more)

### Community 49 - "Community 49"
Cohesion: 0.16
Nodes (22): TradingCard(), GET(), TickerRow, cleanList(), FOREX_SCAN_FALLBACK, isOpenAssetsPolicy(), listIsOpen(), MarketAssets (+14 more)

### Community 50 - "Community 50"
Cohesion: 0.19
Nodes (21): POST(), ChartDrawing, ChartSnapshotInput, canUseMt5ChartCapture(), captureKeyForRecommendation(), dataRoot(), eaChartPngPath(), getPendingChartCapture() (+13 more)

### Community 51 - "Community 51"
Cohesion: 0.10
Nodes (19): AdminUsagePanel(), ADMIN_LIMIT_FIELDS, ClaudeUsageRow, consumeLinkCode(), listAgentAuditLogs(), listAuditLogs(), listClaudeUsageForAdmin(), SETTABLE_FIELDS (+11 more)

### Community 52 - "Community 52"
Cohesion: 0.20
Nodes (13): formatMt5TradeError(), MT5_RETCODE_LEGEND, parseMt5Retcode(), GET(), POST(), schema, EaCommandAckResult, sleep() (+5 more)

### Community 53 - "Community 53"
Cohesion: 0.12
Nodes (27): deliveryReasonAr(), buildProfilePromptHints(), overlaysFromAnalysis(), bufferToChatImage(), ALLOWED_IMAGE_TYPES, buildUserMessageContent(), ChatImageMediaType, fileToChatImage() (+19 more)

### Community 54 - "Community 54"
Cohesion: 0.16
Nodes (29): POST(), getOcoOrderList(), getSymbolFilters(), placeMarketOrder(), roundToStep(), cancelAllFuturesOrders(), CronPostScanResult, runCronPostScan() (+21 more)

### Community 55 - "Community 55"
Cohesion: 0.36
Nodes (10): getFuturesPositions(), checkSlTpProximity(), levelProximity(), collectTradeWatchAlerts(), forexMidPrice(), intentStopsForTrade(), TradeWatchAlert, watchAichartOpenTrades() (+2 more)

### Community 56 - "Community 56"
Cohesion: 0.14
Nodes (12): cairo, fraunces, inter, jetbrainsMono, metadata, getSystemTheme(), ResolvedTheme, resolveTheme() (+4 more)

### Community 57 - "Community 57"
Cohesion: 0.13
Nodes (27): GET(), getPrice(), BinanceLiveQuote, ensureBinanceLiveQuotes(), getBinanceLivePrice(), getBinanceLiveQuotes(), parseAllowedAssets(), quotesByUser (+19 more)

### Community 58 - "Community 58"
Cohesion: 0.25
Nodes (13): getPool(), initPg(), mapRows(), migratePg(), pgExecute(), pgInsertReturningId(), pgLoadBootstrapKeys(), pgLoadPlatformConfig() (+5 more)

### Community 59 - "Community 59"
Cohesion: 0.27
Nodes (10): AgentWakeEvent, EVENT_INSTRUCTIONS, WakeAgentOptions, wakeAgentViaTelegram(), wakeAuditAction(), wasRecentlyWoken(), isAgentWakeEnabled(), buildDailySummary() (+2 more)

### Community 60 - "Community 60"
Cohesion: 0.18
Nodes (9): agentCommandFromCallback(), BotCommandDef, CMD_CALLBACK_MAP, MENU_ACTIONS, postAnalysisButtons(), replyLabelToAgentCommand(), resolveUserMenuInput(), slashCommandToAgentAction() (+1 more)

### Community 61 - "Community 61"
Cohesion: 0.46
Nodes (5): POST(), verifyCronSecret(), listUsersForDailySummary(), listUsersForMonitor(), POST()

### Community 62 - "Community 62"
Cohesion: 0.26
Nodes (14): binanceAdapter, eaAdapter, computeForexLots(), LotSizingResult, roundToStep(), metaApiAdapter, mt5LocalAdapter, BrokerAdapter (+6 more)

### Community 63 - "Community 63"
Cohesion: 0.08
Nodes (29): ChatSquareClient(), ChatImagePayload, imageDataUrl(), ProcessedIntent, ChatMessageRow, Conversation, isTabActive(), MAIN_TABS (+21 more)

### Community 64 - "Community 64"
Cohesion: 0.18
Nodes (19): binanceFuturesAdapter, roundToTick(), cancelFuturesOrder(), FUTURES_BASE_URLS, FuturesOpenOrder, FuturesPlacedOrder, futuresRequest(), FuturesSymbolFilters (+11 more)

### Community 65 - "Community 65"
Cohesion: 0.16
Nodes (18): GET(), patchSchema, PUT(), requireAdmin(), audioFormatFromMime(), audioMimeFromFormat(), geminiApiKey(), isGeminiChatModelId() (+10 more)

### Community 66 - "Community 66"
Cohesion: 0.24
Nodes (12): displayNameForUser(), formatWhatsAppDisplay(), formatAccessExpiryLabel(), countPendingIntents(), countUnreadAlerts(), needsMcpCredentials(), ConsoleMcpPage(), GET() (+4 more)

### Community 67 - "Community 67"
Cohesion: 0.26
Nodes (8): POST(), schema, POST(), schema, queueEaCommandAndWait(), POST(), schema, GET()

### Community 68 - "Community 68"
Cohesion: 0.13
Nodes (14): CHAINS, COMMANDS, UA, GET(), executeTool(), CallFn, CHAINS, CommandMap (+6 more)

### Community 69 - "Community 69"
Cohesion: 0.43
Nodes (7): GET(), serializeMarketAssets(), setMarketAssets(), setWatchlist(), assetList, PUT(), schema

### Community 70 - "Community 70"
Cohesion: 0.14
Nodes (13): AccountSummary, BASE_URLS, BinanceBalance, Candle, OcoOrderListStatus, PlacedOcoOrder, PlacedOrder, placeOcoOrder() (+5 more)

### Community 71 - "Community 71"
Cohesion: 0.27
Nodes (13): EaPositionSyncResult, reconcileEaPositions(), getEaConnection(), getEaSymbolSpec(), parseEaSymbolSpecs(), CRYPTO_ALIASES, findByForexCanonical(), findCaseInsensitive() (+5 more)

### Community 72 - "Community 72"
Cohesion: 0.22
Nodes (6): AdminKeysPanel(), ConfigField, GROUPS, StatusBadge(), ClaudeModelOption, ClaudeModelPicker()

### Community 73 - "Community 73"
Cohesion: 0.29
Nodes (3): CHAINS, COMMANDS, UA

### Community 74 - "Community 74"
Cohesion: 0.23
Nodes (11): POST(), POST(), schema, CompleteProfilePage(), CompleteProfileClient(), getAccessBlockReason(), UserRow, isSyntheticTelegramEmail() (+3 more)

### Community 75 - "Community 75"
Cohesion: 0.21
Nodes (12): Window, setSession(), verifyPassword(), isTelegramConfiguredAsync(), telegramDisplayEmail(), TelegramLoginPayload, verifyTelegramLogin(), POST() (+4 more)

### Community 76 - "Community 76"
Cohesion: 0.10
Nodes (29): AppShell(), DashboardClient(), STATUS_LABEL, OpportunityScanCard(), WaitingRoom(), MeData, QuotaInfo, useMe() (+21 more)

### Community 77 - "Community 77"
Cohesion: 0.29
Nodes (10): POST(), candidateDetail(), forexScanReady(), MonitorCycleEvent, MonitorCycleResult, runMonitorCycle(), scanMarketForUser(), isOnCooldown() (+2 more)

### Community 78 - "Community 78"
Cohesion: 0.48
Nodes (5): BRIDGE_NAV_MORE, BRIDGE_NAV_PRIMARY, BRIDGE_NAV_SECONDARY, bridgeNavLabel(), BridgeShell()

### Community 79 - "Community 79"
Cohesion: 0.27
Nodes (4): ADMIN_ACTION_LABELS, ADMIN_NAV, AdminSecurityPanel(), AuditRow

### Community 80 - "Community 80"
Cohesion: 0.16
Nodes (14): CHART_ANALYZE_TOOL_NAMES, CHART_ANALYZE_TOOLS, RunAgentOptions, TOOLS, ActivityListener, describeToolUse(), emitActivity(), ContentBlock (+6 more)

### Community 81 - "Community 81"
Cohesion: 0.33
Nodes (6): POST(), schema, GET(), getChartCapture(), putChartCapture(), store

### Community 82 - "Community 82"
Cohesion: 0.43
Nodes (7): DELETE(), PATCH(), schema, deleteUser(), setUserAccess(), setUserStatus(), updateAdminLimits()

### Community 83 - "Community 83"
Cohesion: 0.40
Nodes (3): AdminSystemPanel(), HealthPayload, StatusPill()

### Community 84 - "Community 84"
Cohesion: 0.53
Nodes (5): isValidStop(), minStopDistance(), NormalizedMt5Stops, normalizeMt5Stops(), roundPrice()

### Community 85 - "Community 85"
Cohesion: 0.60
Nodes (5): agentChartUrls(), bridgeServiceToken(), chartCaptureUrls(), normalizeToken(), publicAgentChartUrl()

## Knowledge Gaps
- **311 isolated node(s):** `providerSchema`, `bodySchema`, `NormalizedModel`, `patchSchema`, `schema` (+306 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **3 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `handleError()` connect `Community 40` to `Community 0`, `Community 2`, `Community 3`, `Community 5`, `Community 6`, `Community 8`, `Community 13`, `Community 16`, `Community 20`, `Community 21`, `Community 24`, `Community 25`, `Community 26`, `Community 27`, `Community 28`, `Community 31`, `Community 32`, `Community 34`, `Community 35`, `Community 36`, `Community 37`, `Community 38`, `Community 49`, `Community 50`, `Community 52`, `Community 54`, `Community 57`, `Community 65`, `Community 67`, `Community 68`, `Community 69`, `Community 74`, `Community 75`, `Community 81`, `Community 82`?**
  _High betweenness centrality (0.106) - this node is a cross-community bridge._
- **Why does `cn()` connect `Community 15` to `Community 1`, `Community 33`, `Community 4`, `Community 72`, `Community 9`, `Community 10`, `Community 76`, `Community 14`, `Community 79`, `Community 78`, `Community 51`, `Community 83`, `Community 19`, `Community 23`, `Community 29`, `Community 63`?**
  _High betweenness centrality (0.057) - this node is a cross-community bridge._
- **Why does `getSettings()` connect `Community 26` to `Community 0`, `Community 3`, `Community 4`, `Community 8`, `Community 11`, `Community 13`, `Community 18`, `Community 21`, `Community 22`, `Community 24`, `Community 25`, `Community 27`, `Community 31`, `Community 32`, `Community 35`, `Community 40`, `Community 41`, `Community 49`, `Community 50`, `Community 51`, `Community 54`, `Community 55`, `Community 57`, `Community 61`, `Community 66`, `Community 68`, `Community 69`, `Community 77`, `Community 80`?**
  _High betweenness centrality (0.031) - this node is a cross-community bridge._
- **Are the 41 inferred relationships involving `handleError()` (e.g. with `POST()` and `POST()`) actually correct?**
  _`handleError()` has 41 INFERRED edges - model-reasoned connections that need verification._
- **Are the 17 inferred relationships involving `requireAgentAuth()` (e.g. with `POST()` and `DELETE()`) actually correct?**
  _`requireAgentAuth()` has 17 INFERRED edges - model-reasoned connections that need verification._
- **Are the 13 inferred relationships involving `getSettings()` (e.g. with `GET()` and `POST()`) actually correct?**
  _`getSettings()` has 13 INFERRED edges - model-reasoned connections that need verification._
- **Are the 18 inferred relationships involving `requireUser()` (e.g. with `POST()` and `DELETE()`) actually correct?**
  _`requireUser()` has 18 INFERRED edges - model-reasoned connections that need verification._