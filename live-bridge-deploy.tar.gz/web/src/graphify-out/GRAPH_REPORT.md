# Graph Report - web\src  (2026-06-15)

## Corpus Check
- 347 files · ~128,363 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 1769 nodes · 6557 edges · 68 communities (65 shown, 3 thin omitted)
- Extraction: 96% EXTRACTED · 4% INFERRED · 0% AMBIGUOUS · INFERRED: 249 edges (avg confidence: 0.8)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `492df3f5`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- [[_COMMUNITY_Community 0|Community 0]]
- [[_COMMUNITY_Community 1|Community 1]]
- [[_COMMUNITY_Community 2|Community 2]]
- [[_COMMUNITY_Community 3|Community 3]]
- [[_COMMUNITY_Community 4|Community 4]]
- [[_COMMUNITY_Community 5|Community 5]]
- [[_COMMUNITY_Community 6|Community 6]]
- [[_COMMUNITY_Community 7|Community 7]]
- [[_COMMUNITY_Community 8|Community 8]]
- [[_COMMUNITY_Community 9|Community 9]]
- [[_COMMUNITY_Community 10|Community 10]]
- [[_COMMUNITY_Community 11|Community 11]]
- [[_COMMUNITY_Community 12|Community 12]]
- [[_COMMUNITY_Community 13|Community 13]]
- [[_COMMUNITY_Community 14|Community 14]]
- [[_COMMUNITY_Community 15|Community 15]]
- [[_COMMUNITY_Community 16|Community 16]]
- [[_COMMUNITY_Community 17|Community 17]]
- [[_COMMUNITY_Community 18|Community 18]]
- [[_COMMUNITY_Community 19|Community 19]]
- [[_COMMUNITY_Community 20|Community 20]]
- [[_COMMUNITY_Community 21|Community 21]]
- [[_COMMUNITY_Community 22|Community 22]]
- [[_COMMUNITY_Community 23|Community 23]]
- [[_COMMUNITY_Community 24|Community 24]]
- [[_COMMUNITY_Community 25|Community 25]]
- [[_COMMUNITY_Community 26|Community 26]]
- [[_COMMUNITY_Community 27|Community 27]]
- [[_COMMUNITY_Community 28|Community 28]]
- [[_COMMUNITY_Community 29|Community 29]]
- [[_COMMUNITY_Community 30|Community 30]]
- [[_COMMUNITY_Community 31|Community 31]]
- [[_COMMUNITY_Community 32|Community 32]]
- [[_COMMUNITY_Community 33|Community 33]]
- [[_COMMUNITY_Community 34|Community 34]]
- [[_COMMUNITY_Community 35|Community 35]]
- [[_COMMUNITY_Community 36|Community 36]]
- [[_COMMUNITY_Community 37|Community 37]]
- [[_COMMUNITY_Community 38|Community 38]]
- [[_COMMUNITY_Community 39|Community 39]]
- [[_COMMUNITY_Community 40|Community 40]]
- [[_COMMUNITY_Community 41|Community 41]]
- [[_COMMUNITY_Community 42|Community 42]]
- [[_COMMUNITY_Community 43|Community 43]]
- [[_COMMUNITY_Community 44|Community 44]]
- [[_COMMUNITY_Community 45|Community 45]]
- [[_COMMUNITY_Community 47|Community 47]]
- [[_COMMUNITY_Community 49|Community 49]]
- [[_COMMUNITY_Community 50|Community 50]]
- [[_COMMUNITY_Community 51|Community 51]]
- [[_COMMUNITY_Community 52|Community 52]]
- [[_COMMUNITY_Community 53|Community 53]]
- [[_COMMUNITY_Community 54|Community 54]]
- [[_COMMUNITY_Community 55|Community 55]]
- [[_COMMUNITY_Community 56|Community 56]]
- [[_COMMUNITY_Community 57|Community 57]]
- [[_COMMUNITY_Community 58|Community 58]]
- [[_COMMUNITY_Community 59|Community 59]]
- [[_COMMUNITY_Community 60|Community 60]]
- [[_COMMUNITY_Community 61|Community 61]]
- [[_COMMUNITY_Community 62|Community 62]]
- [[_COMMUNITY_Community 63|Community 63]]
- [[_COMMUNITY_Community 64|Community 64]]
- [[_COMMUNITY_Community 65|Community 65]]
- [[_COMMUNITY_Community 68|Community 68]]
- [[_COMMUNITY_Community 71|Community 71]]

## God Nodes (most connected - your core abstractions)
1. `handleError()` - 202 edges
2. `cn()` - 114 edges
3. `getSettings()` - 95 edges
4. `requireUser()` - 92 edges
5. `requireAgentAuth()` - 74 edges
6. `resolveAgentUserId()` - 64 edges
7. `execute()` - 54 edges
8. `logAudit()` - 47 edges
9. `getLimits()` - 44 edges
10. `getCurrentUser()` - 42 edges

## Surprising Connections (you probably didn't know these)
- `AgentConsoleRedirect()` --calls--> `getCurrentUser()`  [INFERRED]
  app/agent/console/page.tsx → lib/auth.ts
- `AgentRedirect()` --calls--> `getCurrentUser()`  [EXTRACTED]
  app/agent/page.tsx → lib/auth.ts
- `GET()` --calls--> `handleError()`  [INFERRED]
  app/api/admin/binance-capture/route.ts → lib/api.ts
- `GET()` --calls--> `requireAdmin()`  [INFERRED]
  app/api/admin/binance-capture/route.ts → lib/api.ts
- `POST()` --calls--> `handleError()`  [INFERRED]
  app/api/admin/binance-capture/route.ts → lib/api.ts

## Import Cycles
- 3-file cycle: `lib/db.ts -> lib/db/index.ts -> lib/env.ts -> lib/db.ts`
- 4-file cycle: `lib/db.ts -> lib/db/index.ts -> lib/db/sqlite.ts -> lib/env.ts -> lib/db.ts`

## Communities (68 total, 3 thin omitted)

### Community 0 - "Community 0"
Cohesion: 0.13
Nodes (32): GET(), htmlPage(), GET(), GET(), getBrokerAdapter(), RunAgentOptions, ActivityListener, respondToApproval() (+24 more)

### Community 1 - "Community 1"
Cohesion: 0.13
Nodes (11): CommitteeFeed(), HeatmapCell, HeatmapGrid(), MacroTicker(), MemoryHighlights(), FlowSignal, WhaleBubbles(), MarketContext (+3 more)

### Community 2 - "Community 2"
Cohesion: 0.19
Nodes (26): deliverSignal(), DeliveryGateResult, DeliveryReason, dispatchAlert(), DispatchAlertOptions, evaluateDelivery(), isTradeAlert(), REASON_AR (+18 more)

### Community 3 - "Community 3"
Cohesion: 0.20
Nodes (19): chartImagePathForRecommendation(), committeeSummaryTelegram(), defaultVote(), evaluateCommittee(), extractText(), parseCommitteeJson(), AttachChartOptions, attachChartToRecommendation() (+11 more)

### Community 4 - "Community 4"
Cohesion: 0.12
Nodes (28): POST(), schema, GET(), HeartbeatBody, POST(), extractBearer(), generateEaToken(), hashEaToken() (+20 more)

### Community 5 - "Community 5"
Cohesion: 0.12
Nodes (38): LLMProvider, AgentModelStatus, buildFallbackRefs(), CROSS_FALLBACK_CANDIDATES, ensureProviderModelRegistered(), execFileAsync, FALLBACK_PROVIDER_ORDER, getAgentModelStatus() (+30 more)

### Community 6 - "Community 6"
Cohesion: 0.10
Nodes (36): DELETE(), GET(), PATCH(), imageSchema, POST(), schema, createSchema, GET() (+28 more)

### Community 7 - "Community 7"
Cohesion: 0.14
Nodes (26): Message, StreamHandlers, SystemPromptInput, ToolDef, callLLM(), callLLMStream(), compatModelId(), CompatProvider (+18 more)

### Community 8 - "Community 8"
Cohesion: 0.18
Nodes (22): POST(), schema, POST(), schema, GET(), POST(), GET(), ApiRestrictions (+14 more)

### Community 9 - "Community 9"
Cohesion: 0.09
Nodes (28): ChatClient(), ChatMessage, MessageBubble(), RecCard(), STATUS_AR, STATUS_CLASS, TradesClient(), PendingIntentQuickActions() (+20 more)

### Community 10 - "Community 10"
Cohesion: 0.11
Nodes (28): arcPath(), AssetDistributionChart(), polarToCartesian(), SLICE_COLORS, InteractivePerformanceChart(), PeriodSelector(), ReportsClient(), DashboardAnalytics() (+20 more)

### Community 11 - "Community 11"
Cohesion: 0.20
Nodes (11): GET(), ConsoleOverviewPage(), ForexConnectionView, getForexConnectionView(), getAdminPlatformStats(), getBinanceAccountMeta(), getSettings(), listUsersForTradeMaintenance() (+3 more)

### Community 12 - "Community 12"
Cohesion: 0.14
Nodes (20): POST(), schema, Window, ADMIN_LIMIT_FIELDS, AdminUserView, ensureUserDefaults(), getUserByTelegramId(), listUsersForMonitor() (+12 more)

### Community 13 - "Community 13"
Cohesion: 0.16
Nodes (25): BinanceEnv, buildConsoleActiveTrades(), loadIntentSlTp(), mapAichartBase(), mapBinanceFuturesRow(), mapMt5Row(), platformLabel(), sideAr() (+17 more)

### Community 14 - "Community 14"
Cohesion: 0.13
Nodes (10): AdminOverview(), MasterKillCard(), ActiveTradesTable(), BridgeOverviewClient(), ConnectionStatus, StatusChip(), StatusChipTone, TONE (+2 more)

### Community 15 - "Community 15"
Cohesion: 0.06
Nodes (45): BRIDGE_NAV_MORE, BRIDGE_NAV_PRIMARY, BRIDGE_NAV_SECONDARY, bridgeNavLabel(), BridgeShell(), PriceChart, SignalsWizardClient(), useBinanceLivePrices() (+37 more)

### Community 16 - "Community 16"
Cohesion: 0.11
Nodes (30): POST(), POST(), schema, GET(), GET(), getPublicAppUrl(), BinanceCaptureConfig, BinanceCaptureMarket (+22 more)

### Community 17 - "Community 17"
Cohesion: 0.06
Nodes (29): botCommands, menuActions, crypto, demo, forex, iadadat, live, qaima (+21 more)

### Community 18 - "Community 18"
Cohesion: 0.10
Nodes (41): accountFooterLines(), AccountProfile, accountTypeAr(), buildAccountProfile(), platformLabel(), appBaseUrl(), ApprovalKind, ApprovalRequestInput (+33 more)

### Community 19 - "Community 19"
Cohesion: 0.09
Nodes (26): AgentRedirect(), STATUS_LABEL, CAPITAL_OPTIONS, Instrument, STEP_LABELS, AgentStatus, AgentStatusBar(), MODE_LABEL (+18 more)

### Community 20 - "Community 20"
Cohesion: 0.06
Nodes (46): CHAINS, COMMANDS, UA, CHAINS, COMMANDS, UA, GET(), CHART_ANALYZE_TOOL_NAMES (+38 more)

### Community 21 - "Community 21"
Cohesion: 0.11
Nodes (35): POST(), schema, POST(), schema, GET(), isAgentBridgeConfigured(), isValidAgentToken(), requireAgentAuth() (+27 more)

### Community 22 - "Community 22"
Cohesion: 0.14
Nodes (15): AdminLayout(), Home(), ChatRedirect(), CommandRedirect(), ConsoleLayout(), metadata, clearSession(), createSessionToken() (+7 more)

### Community 23 - "Community 23"
Cohesion: 0.22
Nodes (11): AgentPlanMode, ANALYSIS_PLAN_TEMPLATE, applyProgress(), cloneTasks(), flattenSubtaskKeys(), getPlanTemplate(), PlanStatus, PlanSubtask (+3 more)

### Community 24 - "Community 24"
Cohesion: 0.21
Nodes (19): POST(), schema, POST(), rawSchema, schema, SL_LABEL, STYLE_LABEL, isAnthropicConfigured() (+11 more)

### Community 25 - "Community 25"
Cohesion: 0.19
Nodes (20): POST(), schema, DELETE(), getPlatformValueAsync(), deleteMtAccount(), saveMtAccount(), clearRpcCache(), getMetaApi() (+12 more)

### Community 26 - "Community 26"
Cohesion: 0.16
Nodes (13): DEFAULT_SYMBOL, Instrument, MarketClient(), PriceChartHandle, Props, LivePriceMap, LivePriceTick, PriceDirection (+5 more)

### Community 27 - "Community 27"
Cohesion: 0.13
Nodes (20): DELETE(), GET(), PATCH(), patchSchema, DELETE(), PATCH(), schema, execute() (+12 more)

### Community 28 - "Community 28"
Cohesion: 0.25
Nodes (20): GET(), GET(), getAnthropicModel(), listAnthropicModels(), getActiveModel(), getActiveProvider(), getProviderApiKey(), isLLMConfigured() (+12 more)

### Community 29 - "Community 29"
Cohesion: 0.33
Nodes (10): AnthropicModelInfo, AnthropicResponse, buildSystemBlocks(), CacheControl, cachedMessages(), cachedTools(), callAnthropic(), callAnthropicStream() (+2 more)

### Community 30 - "Community 30"
Cohesion: 0.11
Nodes (28): OVERLAY_LABELS, applyChartDrawings(), ApplyDrawingsResult, collectDrawingMarkers(), FIB_RATIOS, fibLevels(), markerShape(), numMeta() (+20 more)

### Community 31 - "Community 31"
Cohesion: 0.18
Nodes (17): POST(), getDbBackend(), getDbInfo(), initDb(), insertReturningId(), isPostgresReady(), queryOne(), hashPassword() (+9 more)

### Community 32 - "Community 32"
Cohesion: 0.19
Nodes (18): transaction(), decryptSecret(), encryptSecret(), getKey(), maskKey(), getEncryptionKey(), cache, clearPlatformConfigCache() (+10 more)

### Community 33 - "Community 33"
Cohesion: 0.36
Nodes (8): createEmbedding(), isEmbeddingConfigured(), openAiKey(), synthesizeSpeech(), extractText(), outcomeFromPnl(), parsePostMortemJson(), runTradePostMortem()

### Community 34 - "Community 34"
Cohesion: 0.12
Nodes (21): binanceAdapter, binanceFuturesAdapter, eaAdapter, computeForexLots(), LotSizingResult, roundToStep(), metaApiAdapter, mt5LocalAdapter (+13 more)

### Community 35 - "Community 35"
Cohesion: 0.29
Nodes (10): cosineSimilarity(), filterBySymbolFallback(), insertTradeLesson(), InsertTradeLessonInput, listRecentLessons(), parseEmbedding(), searchSimilarLessons(), SearchSimilarLessonsQuery (+2 more)

### Community 36 - "Community 36"
Cohesion: 0.14
Nodes (12): AccountSummary, BASE_URLS, BinanceBalance, Candle, OcoOrderListStatus, PlacedOcoOrder, PlacedOrder, PUBLIC_DATA_URLS (+4 more)

### Community 37 - "Community 37"
Cohesion: 0.11
Nodes (28): POST(), schema, POST(), schema, GET(), POST(), schema, POST() (+20 more)

### Community 38 - "Community 38"
Cohesion: 0.23
Nodes (13): FUTURES_BASE_URLS, FuturesOpenOrder, FuturesPlacedOrder, FuturesPosition, futuresRequest(), FuturesSymbolFilters, getFuturesBalance(), getFuturesOpenOrders() (+5 more)

### Community 39 - "Community 39"
Cohesion: 0.17
Nodes (14): AppShell(), ChatSquareClient(), DashboardClient(), useMe(), imageDataUrl(), ChatMessageRow, Conversation, isTabActive() (+6 more)

### Community 40 - "Community 40"
Cohesion: 0.22
Nodes (6): AdminKeysPanel(), ConfigField, GROUPS, StatusBadge(), ClaudeModelOption, ClaudeModelPicker()

### Community 41 - "Community 41"
Cohesion: 0.19
Nodes (10): ConsoleConnectPage(), loadConsoleSettingsProps(), getEaConnectionMeta(), getMtAccountMeta(), listAuditLogs(), listClaudeUsageForAdmin(), ConsolePlatformPage(), ConnectSection() (+2 more)

### Community 42 - "Community 42"
Cohesion: 0.21
Nodes (21): GET(), GET(), getKlines(), parseChartDrawingsJson(), ChartOverlayType, OVERLAY_COLORS, overlaysFromRecommendation(), buildChartJson() (+13 more)

### Community 47 - "Community 47"
Cohesion: 0.06
Nodes (41): ForexBackendMode, BrokerAdapter, PlaceOrderContext, BEGINNER_STEPS, EXPERT_STEPS, ALERT_TYPE_LABEL, AlertsCard(), SettingsClient() (+33 more)

### Community 49 - "Community 49"
Cohesion: 0.06
Nodes (67): POST(), schema, TradingCard(), POST(), POST(), GET(), TickerRow, AgentWakeEvent (+59 more)

### Community 50 - "Community 50"
Cohesion: 0.22
Nodes (19): POST(), ChartDrawing, canUseMt5ChartCapture(), captureKeyForRecommendation(), dataRoot(), eaChartPngPath(), getPendingChartCapture(), isEaChartFileReady() (+11 more)

### Community 51 - "Community 51"
Cohesion: 0.08
Nodes (18): ADMIN_ACTION_LABELS, ADMIN_NAV, AdminSecurityPanel(), AuditRow, AdminSystemPanel(), HealthPayload, StatusPill(), AdminUsagePanel() (+10 more)

### Community 52 - "Community 52"
Cohesion: 0.33
Nodes (6): TelegramLoginButton(), isSingleUserMode(), getTelegramLoginConfig(), LoginPage(), RegisterPage(), AdminUsersRedirect()

### Community 53 - "Community 53"
Cohesion: 0.10
Nodes (33): AgentResult, deliveryReasonAr(), DeliveryResult, AnalysisProfile, AnalysisTier, buildProfilePromptHints(), INTRADAY, POSITION (+25 more)

### Community 54 - "Community 54"
Cohesion: 0.11
Nodes (43): POST(), schema, getOcoOrderList(), getSymbolFilters(), placeMarketOrder(), placeOcoOrder(), roundToStep(), roundToTick() (+35 more)

### Community 55 - "Community 55"
Cohesion: 0.22
Nodes (12): getBootstrapFromCache(), getSqliteDb(), initDb(), initSqlite(), migrate(), seedAdminSqlite(), sqliteExecute(), sqliteLoadBootstrapKeys() (+4 more)

### Community 56 - "Community 56"
Cohesion: 0.14
Nodes (12): cairo, fraunces, inter, jetbrainsMono, metadata, getSystemTheme(), ResolvedTheme, resolveTheme() (+4 more)

### Community 57 - "Community 57"
Cohesion: 0.31
Nodes (11): forexBrokerKind(), getForexBackend(), forexPrice(), getUnifiedPrice(), marketLabel(), resolveCrypto(), resolveForex(), resolveSymbol() (+3 more)

### Community 58 - "Community 58"
Cohesion: 0.16
Nodes (24): bootstrapCache, ensureDb(), loadPlatformConfigRows(), query(), setBootstrapCache(), getPool(), initPg(), mapRows() (+16 more)

### Community 59 - "Community 59"
Cohesion: 0.36
Nodes (11): get24hStats(), ema(), macd(), MacdResult, rsi(), sma(), buildForexSnapshot(), buildSnapshot() (+3 more)

### Community 60 - "Community 60"
Cohesion: 0.27
Nodes (10): eaForexInstruments(), GET(), Instrument, metaApiForexInstruments(), searchBinanceInstruments(), FOREX_INSTRUMENTS, FOREX_SET, forexBaseQuote() (+2 more)

### Community 61 - "Community 61"
Cohesion: 0.29
Nodes (9): call(), getMt5BridgeUrl(), headers(), isMt5LocalConfigured(), Mt5Account, Mt5Bar, mt5Order(), Mt5Position (+1 more)

### Community 62 - "Community 62"
Cohesion: 0.22
Nodes (15): GET(), patchSchema, PUT(), audioFormatFromMime(), audioMimeFromFormat(), geminiApiKey(), isGeminiChatModelId(), isGeminiStudioApiKey() (+7 more)

### Community 63 - "Community 63"
Cohesion: 0.48
Nodes (6): clearTelegramChatId(), createLinkCode(), getBotUsername(), DELETE(), GET(), POST()

### Community 64 - "Community 64"
Cohesion: 0.14
Nodes (16): GET(), POST(), schema, schema, POST(), GET(), ApiError, requireActiveUser() (+8 more)

### Community 65 - "Community 65"
Cohesion: 0.24
Nodes (6): AdminUsersTable(), TableMode, listUsersForAdmin(), ConsoleRiskPage(), Props, TradingRiskSection()

### Community 68 - "Community 68"
Cohesion: 0.24
Nodes (12): GET(), GET(), ALLOWED, Candle, GET(), mapInterval(), metaApiForexCandles(), getEaCandles() (+4 more)

### Community 71 - "Community 71"
Cohesion: 0.14
Nodes (28): MT5_RETCODE_LEGEND, GET(), GET(), livePrice(), getPrice(), EaPositionSyncResult, reconcileEaPositions(), getEaConnection() (+20 more)

## Knowledge Gaps
- **288 isolated node(s):** `providerSchema`, `bodySchema`, `NormalizedModel`, `patchSchema`, `schema` (+283 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **3 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `handleError()` connect `Community 37` to `Community 0`, `Community 2`, `Community 3`, `Community 4`, `Community 6`, `Community 8`, `Community 11`, `Community 12`, `Community 13`, `Community 16`, `Community 20`, `Community 21`, `Community 24`, `Community 25`, `Community 27`, `Community 28`, `Community 31`, `Community 38`, `Community 42`, `Community 49`, `Community 50`, `Community 54`, `Community 62`, `Community 63`, `Community 64`, `Community 68`, `Community 71`?**
  _High betweenness centrality (0.084) - this node is a cross-community bridge._
- **Why does `cn()` connect `Community 15` to `Community 65`, `Community 1`, `Community 39`, `Community 40`, `Community 9`, `Community 10`, `Community 11`, `Community 14`, `Community 47`, `Community 51`, `Community 19`, `Community 26`, `Community 30`?**
  _High betweenness centrality (0.066) - this node is a cross-community bridge._
- **Why does `getSettings()` connect `Community 11` to `Community 0`, `Community 2`, `Community 3`, `Community 4`, `Community 6`, `Community 8`, `Community 12`, `Community 13`, `Community 18`, `Community 20`, `Community 21`, `Community 24`, `Community 37`, `Community 41`, `Community 42`, `Community 49`, `Community 50`, `Community 54`, `Community 71`?**
  _High betweenness centrality (0.022) - this node is a cross-community bridge._
- **Are the 34 inferred relationships involving `handleError()` (e.g. with `POST()` and `POST()`) actually correct?**
  _`handleError()` has 34 INFERRED edges - model-reasoned connections that need verification._
- **Are the 10 inferred relationships involving `getSettings()` (e.g. with `GET()` and `POST()`) actually correct?**
  _`getSettings()` has 10 INFERRED edges - model-reasoned connections that need verification._
- **Are the 16 inferred relationships involving `requireUser()` (e.g. with `POST()` and `GET()`) actually correct?**
  _`requireUser()` has 16 INFERRED edges - model-reasoned connections that need verification._
- **Are the 11 inferred relationships involving `requireAgentAuth()` (e.g. with `POST()` and `POST()`) actually correct?**
  _`requireAgentAuth()` has 11 INFERRED edges - model-reasoned connections that need verification._