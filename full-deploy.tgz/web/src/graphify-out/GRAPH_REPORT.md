# Graph Report - web\src  (2026-06-18)

## Corpus Check
- 433 files · ~150,306 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 2150 nodes · 8252 edges · 90 communities (87 shown, 3 thin omitted)
- Extraction: 96% EXTRACTED · 4% INFERRED · 0% AMBIGUOUS · INFERRED: 343 edges (avg confidence: 0.8)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `3d94eb11`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- [[_COMMUNITY_Community 0|Community 0]]
- [[_COMMUNITY_Community 1|Community 1]]
- [[_COMMUNITY_Community 2|Community 2]]
- [[_COMMUNITY_Community 3|Community 3]]
- [[_COMMUNITY_Community 4|Community 4]]
- [[_COMMUNITY_Community 5|Community 5]]
- [[_COMMUNITY_Community 6|Community 6]]
- [[_COMMUNITY_Community 7|Community 7]]
- [[_COMMUNITY_Community 8|Community 8]]
- [[_COMMUNITY_Community 9|Community 9]]
- [[_COMMUNITY_Community 10|Community 10]]
- [[_COMMUNITY_Community 11|Community 11]]
- [[_COMMUNITY_Community 12|Community 12]]
- [[_COMMUNITY_Community 13|Community 13]]
- [[_COMMUNITY_Community 14|Community 14]]
- [[_COMMUNITY_Community 15|Community 15]]
- [[_COMMUNITY_Community 16|Community 16]]
- [[_COMMUNITY_Community 17|Community 17]]
- [[_COMMUNITY_Community 18|Community 18]]
- [[_COMMUNITY_Community 19|Community 19]]
- [[_COMMUNITY_Community 20|Community 20]]
- [[_COMMUNITY_Community 21|Community 21]]
- [[_COMMUNITY_Community 22|Community 22]]
- [[_COMMUNITY_Community 23|Community 23]]
- [[_COMMUNITY_Community 24|Community 24]]
- [[_COMMUNITY_Community 25|Community 25]]
- [[_COMMUNITY_Community 26|Community 26]]
- [[_COMMUNITY_Community 27|Community 27]]
- [[_COMMUNITY_Community 28|Community 28]]
- [[_COMMUNITY_Community 29|Community 29]]
- [[_COMMUNITY_Community 30|Community 30]]
- [[_COMMUNITY_Community 31|Community 31]]
- [[_COMMUNITY_Community 32|Community 32]]
- [[_COMMUNITY_Community 33|Community 33]]
- [[_COMMUNITY_Community 34|Community 34]]
- [[_COMMUNITY_Community 35|Community 35]]
- [[_COMMUNITY_Community 36|Community 36]]
- [[_COMMUNITY_Community 37|Community 37]]
- [[_COMMUNITY_Community 38|Community 38]]
- [[_COMMUNITY_Community 39|Community 39]]
- [[_COMMUNITY_Community 40|Community 40]]
- [[_COMMUNITY_Community 41|Community 41]]
- [[_COMMUNITY_Community 42|Community 42]]
- [[_COMMUNITY_Community 43|Community 43]]
- [[_COMMUNITY_Community 44|Community 44]]
- [[_COMMUNITY_Community 45|Community 45]]
- [[_COMMUNITY_Community 47|Community 47]]
- [[_COMMUNITY_Community 49|Community 49]]
- [[_COMMUNITY_Community 50|Community 50]]
- [[_COMMUNITY_Community 51|Community 51]]
- [[_COMMUNITY_Community 52|Community 52]]
- [[_COMMUNITY_Community 53|Community 53]]
- [[_COMMUNITY_Community 54|Community 54]]
- [[_COMMUNITY_Community 55|Community 55]]
- [[_COMMUNITY_Community 56|Community 56]]
- [[_COMMUNITY_Community 57|Community 57]]
- [[_COMMUNITY_Community 58|Community 58]]
- [[_COMMUNITY_Community 59|Community 59]]
- [[_COMMUNITY_Community 60|Community 60]]
- [[_COMMUNITY_Community 61|Community 61]]
- [[_COMMUNITY_Community 62|Community 62]]
- [[_COMMUNITY_Community 63|Community 63]]
- [[_COMMUNITY_Community 64|Community 64]]
- [[_COMMUNITY_Community 65|Community 65]]
- [[_COMMUNITY_Community 66|Community 66]]
- [[_COMMUNITY_Community 67|Community 67]]
- [[_COMMUNITY_Community 68|Community 68]]
- [[_COMMUNITY_Community 69|Community 69]]
- [[_COMMUNITY_Community 70|Community 70]]
- [[_COMMUNITY_Community 71|Community 71]]
- [[_COMMUNITY_Community 72|Community 72]]
- [[_COMMUNITY_Community 73|Community 73]]
- [[_COMMUNITY_Community 74|Community 74]]
- [[_COMMUNITY_Community 75|Community 75]]
- [[_COMMUNITY_Community 76|Community 76]]
- [[_COMMUNITY_Community 77|Community 77]]
- [[_COMMUNITY_Community 78|Community 78]]
- [[_COMMUNITY_Community 79|Community 79]]
- [[_COMMUNITY_Community 80|Community 80]]
- [[_COMMUNITY_Community 81|Community 81]]
- [[_COMMUNITY_Community 82|Community 82]]
- [[_COMMUNITY_Community 83|Community 83]]
- [[_COMMUNITY_Community 84|Community 84]]
- [[_COMMUNITY_Community 85|Community 85]]
- [[_COMMUNITY_Community 86|Community 86]]
- [[_COMMUNITY_Community 87|Community 87]]
- [[_COMMUNITY_Community 88|Community 88]]
- [[_COMMUNITY_Community 89|Community 89]]

## God Nodes (most connected - your core abstractions)
1. `handleError()` - 235 edges
2. `cn()` - 122 edges
3. `getSettings()` - 111 edges
4. `requireAgentAuth()` - 101 edges
5. `resolveBridgeUserId()` - 95 edges
6. `requireUser()` - 95 edges
7. `resolveAgentUserId()` - 91 edges
8. `requirePlatformAccess()` - 91 edges
9. `execute()` - 60 edges
10. `logAudit()` - 56 edges

## Surprising Connections (you probably didn't know these)
- `AdminUsersRedirect()` --calls--> `isSingleUserMode()`  [EXTRACTED]
  app/admin/users/page.tsx → lib/agentAuth.ts
- `AgentConsoleRedirect()` --calls--> `getCurrentUser()`  [INFERRED]
  app/agent/console/page.tsx → lib/auth.ts
- `GET()` --calls--> `handleError()`  [INFERRED]
  app/api/admin/binance-capture/route.ts → lib/api.ts
- `GET()` --calls--> `requireAdmin()`  [INFERRED]
  app/api/admin/binance-capture/route.ts → lib/api.ts
- `POST()` --calls--> `handleError()`  [INFERRED]
  app/api/admin/binance-capture/route.ts → lib/api.ts

## Import Cycles
- 2-file cycle: `lib/market.ts -> lib/markets/forexSnapshot.ts -> lib/market.ts`
- 3-file cycle: `lib/db.ts -> lib/db/index.ts -> lib/env.ts -> lib/db.ts`
- 4-file cycle: `lib/db.ts -> lib/db/index.ts -> lib/db/sqlite.ts -> lib/env.ts -> lib/db.ts`

## Communities (90 total, 3 thin omitted)

### Community 0 - "Community 0"
Cohesion: 0.11
Nodes (28): clearEaLiveQuotesForTests(), EaLiveEvent, EaLiveQuote, EaLiveQuotesSummary, EnrichedEaLiveQuote, eventsByUser, getEaLiveQuote(), getOrCreateUserMap() (+20 more)

### Community 1 - "Community 1"
Cohesion: 0.13
Nodes (11): CommitteeFeed(), HeatmapCell, HeatmapGrid(), MacroTicker(), MemoryHighlights(), FlowSignal, WhaleBubbles(), MarketContext (+3 more)

### Community 2 - "Community 2"
Cohesion: 0.13
Nodes (23): bridgeError(), BridgeErrorBody, BridgeErrorCode, bridgeSuccess, DEFAULT_RETRIABLE, HTTP_STATUS, httpStatusForEnvelope(), lowConfidenceFailure() (+15 more)

### Community 3 - "Community 3"
Cohesion: 0.13
Nodes (29): AgentResult, CHART_ANALYZE_TOOL_NAMES, CHART_ANALYZE_TOOLS, executeTool(), TOOLS, DeliveryResult, CliResult, isBinanceCliEnabled() (+21 more)

### Community 4 - "Community 4"
Cohesion: 0.12
Nodes (17): ForexBackendMode, forexBrokerKind(), ALERT_TYPE_LABEL, AlertsCard(), TabId, TABS, ForexConnectionView, AlertLog (+9 more)

### Community 5 - "Community 5"
Cohesion: 0.18
Nodes (13): GET(), AgentModelStatus, buildFallbackRefs(), CROSS_FALLBACK_CANDIDATES, FALLBACK_PROVIDER_ORDER, getAgentModelStatus(), isAllowedModelRef(), PROVIDER_BASE_URL (+5 more)

### Community 6 - "Community 6"
Cohesion: 0.14
Nodes (25): DELETE(), GET(), PATCH(), imageSchema, schema, createSchema, GET(), Params (+17 more)

### Community 7 - "Community 7"
Cohesion: 0.11
Nodes (34): AnthropicModelInfo, AnthropicResponse, buildSystemBlocks(), CacheControl, cachedMessages(), cachedTools(), callAnthropic(), callAnthropicStream() (+26 more)

### Community 8 - "Community 8"
Cohesion: 0.20
Nodes (21): POST(), schema, POST(), schema, GET(), POST(), GET(), ApiRestrictions (+13 more)

### Community 9 - "Community 9"
Cohesion: 0.09
Nodes (30): ChatClient(), ChatMessage, MessageBubble(), RecCard(), ChatSquareClient(), STATUS_AR, STATUS_CLASS, TradesClient() (+22 more)

### Community 10 - "Community 10"
Cohesion: 0.10
Nodes (30): arcPath(), AssetDistributionChart(), polarToCartesian(), SLICE_COLORS, InteractivePerformanceChart(), PeriodSelector(), STATUS_LABEL, ReportsClient() (+22 more)

### Community 11 - "Community 11"
Cohesion: 0.33
Nodes (8): allowedAssetsLabel(), getForexConnectionView(), buildSystemPrompt(), chartAnalyzeSystemSuffix(), SystemPromptParts, listRecommendations(), buildUserContext(), GET()

### Community 12 - "Community 12"
Cohesion: 0.05
Nodes (70): initialCountry(), LABELS, PhoneInput(), PRIORITY, TelegramLoginButton(), Window, GET(), isSingleUserMode() (+62 more)

### Community 13 - "Community 13"
Cohesion: 0.16
Nodes (28): GET(), BinanceEnv, buildConsoleActiveTrades(), loadIntentSlTp(), mapAichartBase(), mapBinanceFuturesRow(), mapMt5Row(), platformLabel() (+20 more)

### Community 14 - "Community 14"
Cohesion: 0.11
Nodes (14): AdminOverview(), MasterKillCard(), ActiveTradesTable(), ConnectionStatus, StatusChip(), StatusChipTone, TONE, AgentStatus (+6 more)

### Community 15 - "Community 15"
Cohesion: 0.11
Nodes (22): DEFAULT_SYMBOL, Instrument, MarketClient(), OVERLAY_LABELS, PriceChart, PriceChartHandle, Props, LivePriceMap (+14 more)

### Community 16 - "Community 16"
Cohesion: 0.17
Nodes (22): POST(), POST(), schema, GET(), BinanceCaptureConfig, BinanceCaptureMarket, binanceChartUrl(), cacheKey() (+14 more)

### Community 17 - "Community 17"
Cohesion: 0.06
Nodes (29): botCommands, menuActions, crypto, demo, forex, iadadat, live, qaima (+21 more)

### Community 18 - "Community 18"
Cohesion: 0.06
Nodes (77): GET(), htmlPage(), GET(), schema, GET, schema, getBrokerAdapter(), POST() (+69 more)

### Community 19 - "Community 19"
Cohesion: 0.06
Nodes (28): AppShell(), DashboardClient(), BEGINNER_STEPS, EXPERT_STEPS, CAPITAL_OPTIONS, Instrument, SignalsWizardClient(), STEP_LABELS (+20 more)

### Community 20 - "Community 20"
Cohesion: 0.27
Nodes (15): get24hStats(), ema(), macd(), MacdResult, rsi(), sma(), buildSnapshot(), computeForexIndicators() (+7 more)

### Community 21 - "Community 21"
Cohesion: 0.11
Nodes (45): GET(), POST(), schema, GET(), GET(), drawingSchema, POST(), schema (+37 more)

### Community 22 - "Community 22"
Cohesion: 0.12
Nodes (21): ConsoleAccountPage(), AdminLayout(), AgentRedirect(), BridgeOverviewClient(), ChatRedirect(), CommandRedirect(), AgentConsoleRedirect(), ConsoleOverviewPage() (+13 more)

### Community 23 - "Community 23"
Cohesion: 0.22
Nodes (11): AgentPlanMode, ANALYSIS_PLAN_TEMPLATE, applyProgress(), cloneTasks(), flattenSubtaskKeys(), getPlanTemplate(), PlanStatus, PlanSubtask (+3 more)

### Community 24 - "Community 24"
Cohesion: 0.19
Nodes (23): POST(), schema, GET(), POST(), POST(), rawSchema, schema, SL_LABEL (+15 more)

### Community 25 - "Community 25"
Cohesion: 0.16
Nodes (20): GET(), getForexBackend(), ConsoleConnectPage(), GET(), ALLOWED, Candle, GET(), mapInterval() (+12 more)

### Community 26 - "Community 26"
Cohesion: 0.19
Nodes (25): GET(), GET(), getKlines(), parseChartDrawingsJson(), buildChartImageUrl(), ChartOverlay, ChartOverlayType, overlaysFromRecommendation() (+17 more)

### Community 27 - "Community 27"
Cohesion: 0.21
Nodes (15): queryOne(), pgQueryOne(), hashPassword(), normalizeWhatsApp(), ensureUserDefaults(), getUserByTelegramId(), setTelegramChatId(), uniqueTelegramEmail() (+7 more)

### Community 28 - "Community 28"
Cohesion: 0.28
Nodes (17): modelRefFromPlatform(), getAnthropicModel(), listAnthropicModels(), getPublicAppUrl(), compatTarget(), getActiveModel(), getProviderApiKey(), providerKeyField() (+9 more)

### Community 29 - "Community 29"
Cohesion: 0.17
Nodes (9): AdminUsersTable(), formatExpiry(), formatExpiryCell(), TableMode, AdminUserView, ConsoleRiskPage(), Props, TradingRiskSection() (+1 more)

### Community 30 - "Community 30"
Cohesion: 0.13
Nodes (26): applyChartDrawings(), ApplyDrawingsResult, collectDrawingMarkers(), FIB_RATIOS, fibLevels(), markerShape(), numMeta(), pointArrMeta() (+18 more)

### Community 31 - "Community 31"
Cohesion: 0.15
Nodes (19): GET(), POST(), schema, extractBearer(), generateEaToken(), hashEaToken(), requireEaConnection(), pushEaEvent() (+11 more)

### Community 32 - "Community 32"
Cohesion: 0.21
Nodes (18): POST(), schema, POST(), schema, HeartbeatBody, POST(), createEaCommand(), recordEaHeartbeat() (+10 more)

### Community 33 - "Community 33"
Cohesion: 0.19
Nodes (11): LandingAccess(), LANDING, LandingCta(), LandingFaq(), LandingFeatures(), LandingFooter(), LandingHero(), LandingHowItWorks() (+3 more)

### Community 34 - "Community 34"
Cohesion: 0.14
Nodes (22): POST(), schema, GET(), GET(), livePrice(), ackEaCommand(), computeMissedHeartbeats(), EaCandleRow (+14 more)

### Community 35 - "Community 35"
Cohesion: 0.17
Nodes (17): POST(), schema, OpportunityScanCard(), WaitingRoom(), INTERVAL_SET, MARKET_INTERVALS, MarketInterval, normalizeInterval() (+9 more)

### Community 36 - "Community 36"
Cohesion: 0.33
Nodes (9): createEmbedding(), isEmbeddingConfigured(), openAiKey(), synthesizeSpeech(), insertTradeLesson(), extractText(), outcomeFromPnl(), parsePostMortemJson() (+1 more)

### Community 37 - "Community 37"
Cohesion: 0.12
Nodes (27): DELETE(), GET(), PATCH(), patchSchema, DELETE(), GET(), DELETE(), GET() (+19 more)

### Community 38 - "Community 38"
Cohesion: 0.21
Nodes (12): ChartDrawing, drawingPriceBounds(), Mt5ChartCaptureInput, CheckInput, intentAgeMinutes(), OpportunityCheck, OpportunityVerdict, validateOpportunity() (+4 more)

### Community 39 - "Community 39"
Cohesion: 0.27
Nodes (9): getBootstrapFromCache(), decryptSecret(), encryptSecret(), getKey(), maskKey(), getAppSecret(), getEncryptionKey(), readBootstrapKey() (+1 more)

### Community 40 - "Community 40"
Cohesion: 0.13
Nodes (20): POST(), DELETE(), DELETE(), POST(), POST(), schema, schema, GET() (+12 more)

### Community 41 - "Community 41"
Cohesion: 0.23
Nodes (9): AwaitingApprovalPage(), AwaitingApprovalClient(), COPY, AccessBlockReason, accessDaysRemaining(), formatAccessRemaining(), UserWithAccess, Role (+1 more)

### Community 42 - "Community 42"
Cohesion: 0.15
Nodes (20): getCached, setCached, BuildTradeReadinessInput, GET, ApprovalRequestInput, queueEaGetOhlc(), getEaCandles(), ProcessRecommendationsOptions (+12 more)

### Community 47 - "Community 47"
Cohesion: 0.19
Nodes (22): bootstrapCache, ensureDb(), getDbBackend(), getDbInfo(), initDb(), insertReturningId(), isPostgresReady(), loadPlatformConfigRows() (+14 more)

### Community 49 - "Community 49"
Cohesion: 0.15
Nodes (27): TradingCard(), GET(), TickerRow, cleanList(), FOREX_SCAN_FALLBACK, isOpenAssetsPolicy(), isSymbolAllowed(), listIsOpen() (+19 more)

### Community 50 - "Community 50"
Cohesion: 0.21
Nodes (18): POST(), canUseMt5ChartCapture(), captureKeyForRecommendation(), dataRoot(), eaChartPngPath(), isEaChartFileReady(), isEaOnline(), Mt5ChartCaptureResult (+10 more)

### Community 51 - "Community 51"
Cohesion: 0.10
Nodes (30): DELETE(), PATCH(), schema, execute(), setConversationSummary(), setEaStatus(), computeAccessExpiresAt(), ADMIN_LIMIT_FIELDS (+22 more)

### Community 52 - "Community 52"
Cohesion: 0.43
Nodes (6): POST(), schema, waitForEaCommandAck(), queueEaModifySlTp(), POST(), schema

### Community 53 - "Community 53"
Cohesion: 0.11
Nodes (34): GET(), deliveryReasonAr(), AnalysisProfile, AnalysisTier, buildProfilePromptHints(), INTRADAY, POSITION, profileForInterval() (+26 more)

### Community 54 - "Community 54"
Cohesion: 0.17
Nodes (28): getOcoOrderList(), getSymbolFilters(), placeMarketOrder(), roundToStep(), CronPostScanResult, runCronPostScan(), runUserPostScan(), MonitorCycleResult (+20 more)

### Community 55 - "Community 55"
Cohesion: 0.15
Nodes (22): AgentContext, checkSlTpProximity(), levelProximity(), ProximityHit, ProximityKind, scanForexSymbol(), scanSymbol(), scoreOpportunity() (+14 more)

### Community 56 - "Community 56"
Cohesion: 0.13
Nodes (13): cairo, fraunces, inter, jetbrainsMono, metadata, getSystemTheme(), ResolvedTheme, resolveTheme() (+5 more)

### Community 57 - "Community 57"
Cohesion: 0.20
Nodes (16): getPrice(), BinanceLiveQuote, ensureBinanceLiveQuotes(), getBinanceLivePrice(), getBinanceLiveQuotes(), parseAllowedAssets(), quotesByUser, refreshInFlight (+8 more)

### Community 58 - "Community 58"
Cohesion: 0.20
Nodes (16): getPool(), initPg(), mapRows(), migratePg(), pgExecute(), pgInsertReturningId(), pgLoadBootstrapKeys(), pgLoadPlatformConfig() (+8 more)

### Community 59 - "Community 59"
Cohesion: 0.13
Nodes (23): BridgeCacheEntry, BridgeCacheHit, bridgeCacheKey(), BridgeCacheMiss, BridgeCacheResult, clearBridgeCache(), defaultTtlMs(), getBridgeCacheTtlMs() (+15 more)

### Community 60 - "Community 60"
Cohesion: 0.24
Nodes (22): POST(), connectMtAccount(), disconnectMtAccount(), formatMtConnectError(), MtConnectInput, mtConnectSchema, deleteMtAccount(), saveMtAccount() (+14 more)

### Community 61 - "Community 61"
Cohesion: 0.16
Nodes (19): invalidateCached, BridgeEnvelope, ForexQuoteSnapshot, FreshnessSource, expiresAtIso(), getIdempotencyResult(), IdempotencyRecord, readIdempotencyKey() (+11 more)

### Community 62 - "Community 62"
Cohesion: 0.21
Nodes (19): binanceAdapter, eaAdapter, finalizeAck(), sideQuotePrice(), computeForexLots(), LotSizingResult, roundToStep(), metaApiAdapter (+11 more)

### Community 63 - "Community 63"
Cohesion: 0.08
Nodes (33): ChatImagePayload, INTERVAL_GROUPS, cn(), IntervalPicker(), MarketTickerBar(), TickerStat, MarketTypeSelector(), OPTIONS (+25 more)

### Community 64 - "Community 64"
Cohesion: 0.17
Nodes (20): binanceFuturesAdapter, roundToTick(), cancelFuturesOrder(), FUTURES_BASE_URLS, FuturesOpenOrder, FuturesPlacedOrder, FuturesPosition, futuresRequest() (+12 more)

### Community 65 - "Community 65"
Cohesion: 0.12
Nodes (30): POST(), schema, GET(), patchSchema, PUT(), GET(), requireAdmin(), audioFormatFromMime() (+22 more)

### Community 66 - "Community 66"
Cohesion: 0.16
Nodes (16): SettingsClient(), displayNameForUser(), displayNameFromEmail(), DEFAULT_COUNTRY, formatWhatsAppDisplay(), formatAccessExpiryLabel(), needsMcpCredentials(), ConsoleMcpPage() (+8 more)

### Community 67 - "Community 67"
Cohesion: 0.21
Nodes (10): POST(), schema, POST(), schema, queueEaCommandAndWait(), EaCommand, EaCommandType, POST() (+2 more)

### Community 68 - "Community 68"
Cohesion: 0.23
Nodes (10): GET(), CallFn, CHAINS, CommandMap, cryptoMarketRank(), marketRank, MarketRankCommand, SkillReq (+2 more)

### Community 69 - "Community 69"
Cohesion: 0.14
Nodes (15): CompleteProfilePage(), CompleteProfileClient(), MeData, QuotaInfo, BinanceAccountMeta, CommitteePersonaVote, CommitteeVoteValue, EaClearChartPayload (+7 more)

### Community 70 - "Community 70"
Cohesion: 0.14
Nodes (13): AccountSummary, BASE_URLS, BinanceBalance, Candle, OcoOrderListStatus, PlacedOcoOrder, PlacedOrder, placeOcoOrder() (+5 more)

### Community 71 - "Community 71"
Cohesion: 0.29
Nodes (16): checkForexTradePreflight(), heartbeatQuoteAgeMs(), resolveForexQuoteSnapshot(), getEaConnection(), parseEaSymbolSpecs(), forexLivePrice(), forexScanReady(), MonitorCycleEvent (+8 more)

### Community 72 - "Community 72"
Cohesion: 0.06
Nodes (21): AdminKeysPanel(), ConfigField, GROUPS, StatusBadge(), ADMIN_ACTION_LABELS, ADMIN_NAV, AdminSecurityPanel(), AuditRow (+13 more)

### Community 73 - "Community 73"
Cohesion: 0.29
Nodes (3): CHAINS, COMMANDS, UA

### Community 74 - "Community 74"
Cohesion: 0.26
Nodes (12): POST(), POST(), schema, getAccessBlockReason(), countPendingIntents(), countUnreadAlerts(), UserRow, isSyntheticTelegramEmail() (+4 more)

### Community 75 - "Community 75"
Cohesion: 0.25
Nodes (11): Home(), ConsoleLayout(), metadata, setSession(), verifyPassword(), hasPlatformAccess(), isOnboardingDone(), POST() (+3 more)

### Community 76 - "Community 76"
Cohesion: 0.12
Nodes (28): evaluateForexQuoteGate(), defaultMaxSpreadPips(), defaultStaleThresholdMs(), freshnessMeta, getMaxSpreadPips(), getStaleQuoteThresholdMs(), isQuoteFresh(), blocker() (+20 more)

### Community 77 - "Community 77"
Cohesion: 0.21
Nodes (12): eaForexInstruments(), GET(), Instrument, metaApiForexInstruments(), BinanceInstrument, BinanceSymbolRow, searchBinanceInstruments(), FOREX_INSTRUMENTS (+4 more)

### Community 78 - "Community 78"
Cohesion: 0.48
Nodes (5): BRIDGE_NAV_MORE, BRIDGE_NAV_PRIMARY, BRIDGE_NAV_SECONDARY, bridgeNavLabel(), BridgeShell()

### Community 79 - "Community 79"
Cohesion: 0.22
Nodes (9): GET, OhlcCandle, clusterLevels(), DetectedLevel, detectStructureLevels(), inferStructure(), isSwingHigh(), isSwingLow() (+1 more)

### Community 80 - "Community 80"
Cohesion: 0.20
Nodes (12): ContentBlock, ALLOWED_IMAGE_TYPES, ChatImageMediaType, fileToChatImage(), imageDataUrl(), isAllowedImageType(), parseImageFromMetadata(), validateChatImage() (+4 more)

### Community 81 - "Community 81"
Cohesion: 0.33
Nodes (6): POST(), schema, GET(), getChartCapture(), putChartCapture(), store

### Community 82 - "Community 82"
Cohesion: 0.23
Nodes (4): BridgeKvStore, getRedisClient(), MemoryKvStore, RedisKvStore

### Community 83 - "Community 83"
Cohesion: 0.21
Nodes (8): changePct(), computeForex24hRange(), Forex24hRange, highLowFromWindow(), HighLowWindow, emptyForexSnapshot(), ForexMarketSnapshot, ForexSnapshotMeta

### Community 84 - "Community 84"
Cohesion: 0.53
Nodes (5): isValidStop(), minStopDistance(), NormalizedMt5Stops, normalizeMt5Stops(), roundPrice()

### Community 85 - "Community 85"
Cohesion: 0.60
Nodes (5): agentChartUrls(), bridgeServiceToken(), chartCaptureUrls(), normalizeToken(), publicAgentChartUrl()

### Community 86 - "Community 86"
Cohesion: 0.27
Nodes (9): call(), getMt5BridgeUrl(), headers(), Mt5Account, Mt5Bar, mt5Order(), Mt5Position, mt5Price() (+1 more)

### Community 87 - "Community 87"
Cohesion: 0.32
Nodes (6): isRetriableEaFailure(), formatMt5TradeError(), MT5_RETCODE_LEGEND, parseMt5Retcode(), EaCommandAckResult, sleep()

### Community 88 - "Community 88"
Cohesion: 0.29
Nodes (3): CHAINS, COMMANDS, UA

### Community 89 - "Community 89"
Cohesion: 0.67
Nodes (3): EaPositionSyncResult, reconcileEaPositions(), getEaSymbolSpec()

## Knowledge Gaps
- **339 isolated node(s):** `providerSchema`, `bodySchema`, `NormalizedModel`, `patchSchema`, `schema` (+334 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **3 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `handleError()` connect `Community 40` to `Community 2`, `Community 3`, `Community 5`, `Community 6`, `Community 8`, `Community 11`, `Community 12`, `Community 13`, `Community 16`, `Community 18`, `Community 21`, `Community 22`, `Community 24`, `Community 25`, `Community 26`, `Community 27`, `Community 28`, `Community 31`, `Community 32`, `Community 34`, `Community 35`, `Community 37`, `Community 49`, `Community 50`, `Community 51`, `Community 52`, `Community 53`, `Community 60`, `Community 65`, `Community 67`, `Community 68`, `Community 74`, `Community 75`, `Community 81`?**
  _High betweenness centrality (0.067) - this node is a cross-community bridge._
- **Why does `getSettings()` connect `Community 18` to `Community 2`, `Community 3`, `Community 6`, `Community 8`, `Community 11`, `Community 12`, `Community 13`, `Community 21`, `Community 22`, `Community 24`, `Community 25`, `Community 26`, `Community 27`, `Community 32`, `Community 35`, `Community 37`, `Community 42`, `Community 49`, `Community 50`, `Community 51`, `Community 54`, `Community 55`, `Community 57`, `Community 61`, `Community 74`, `Community 75`, `Community 76`, `Community 79`?**
  _High betweenness centrality (0.038) - this node is a cross-community bridge._
- **Why does `cn()` connect `Community 63` to `Community 1`, `Community 66`, `Community 33`, `Community 4`, `Community 72`, `Community 9`, `Community 10`, `Community 12`, `Community 78`, `Community 14`, `Community 15`, `Community 19`, `Community 29`?**
  _High betweenness centrality (0.036) - this node is a cross-community bridge._
- **Are the 41 inferred relationships involving `handleError()` (e.g. with `POST()` and `POST()`) actually correct?**
  _`handleError()` has 41 INFERRED edges - model-reasoned connections that need verification._
- **Are the 13 inferred relationships involving `getSettings()` (e.g. with `GET()` and `POST()`) actually correct?**
  _`getSettings()` has 13 INFERRED edges - model-reasoned connections that need verification._
- **Are the 17 inferred relationships involving `requireAgentAuth()` (e.g. with `POST()` and `DELETE()`) actually correct?**
  _`requireAgentAuth()` has 17 INFERRED edges - model-reasoned connections that need verification._
- **Are the 17 inferred relationships involving `resolveBridgeUserId()` (e.g. with `POST()` and `DELETE()`) actually correct?**
  _`resolveBridgeUserId()` has 17 INFERRED edges - model-reasoned connections that need verification._