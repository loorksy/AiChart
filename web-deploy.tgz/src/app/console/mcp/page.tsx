import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { SurfaceCard } from "@/components/ui/shell";

export default async function ConsoleMcpPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (user.role === "admin") redirect("/console/platform?tab=system");

  const mcpUrl =
    process.env.MCP_PUBLIC_URL?.trim() || "https://aichart.lork.cloud/mcp";

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <h1 className="text-2xl font-bold">ربط Claude MCP</h1>
      <SurfaceCard className="space-y-4 text-sm">
        <ol className="list-decimal space-y-3 ps-5">
          <li>
            افتح{" "}
            <a
              href="https://claude.ai/customize/connectors"
              className="text-link"
              target="_blank"
              rel="noopener noreferrer"
            >
              Claude Connectors
            </a>
          </li>
          <li>Add custom connector → الاسم: AiChart Trading</li>
          <li>
            Remote MCP URL:{" "}
            <code className="rounded bg-secondary px-1" dir="ltr">
              {mcpUrl}
            </code>
          </li>
          <li>OAuth Client ID/Secret: اتركهما فارغين</li>
          <li>سجّل دخول بحسابك في AiChart (بريد + كلمة المرور)</li>
        </ol>
        <p className="text-muted-foreground">
          بعد الربط تظهر أدوات التداول في محادثة Claude — القرار معك، التنفيذ عبر
          Risk Guard.
        </p>
      </SurfaceCard>
    </div>
  );
}
