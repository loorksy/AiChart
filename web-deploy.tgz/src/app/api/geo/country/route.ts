import { NextResponse } from "next/server";
import { headers } from "next/headers";
import { detectCountryFromHeaders } from "@/lib/geoCountry";

export async function GET() {
  const h = await headers();
  const country = detectCountryFromHeaders(h);
  return NextResponse.json({ country });
}
