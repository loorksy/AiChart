import type { CountryCode } from "libphonenumber-js";
import { getCountries } from "libphonenumber-js";

const VALID = new Set(getCountries());

const TIMEZONE_COUNTRY: Record<string, CountryCode> = {
  "Asia/Riyadh": "SA",
  "Asia/Dubai": "AE",
  "Asia/Kuwait": "KW",
  "Asia/Qatar": "QA",
  "Asia/Bahrain": "BH",
  "Asia/Muscat": "OM",
  "Asia/Amman": "JO",
  "Asia/Beirut": "LB",
  "Asia/Baghdad": "IQ",
  "Africa/Cairo": "EG",
};

function isValidCountry(code: string | null | undefined): code is CountryCode {
  return Boolean(code && VALID.has(code as CountryCode));
}

function countryFromAcceptLanguage(raw: string | null): CountryCode | null {
  if (!raw) return null;
  for (const part of raw.split(",")) {
    const tag = part.split(";")[0]?.trim();
    const region = tag?.split("-")[1]?.toUpperCase();
    if (isValidCountry(region)) return region;
  }
  return null;
}

function countryFromTimezone(tz: string | null | undefined): CountryCode | null {
  if (!tz) return null;
  return TIMEZONE_COUNTRY[tz] ?? null;
}

/** Detect ISO country from request headers (SSR / API). Falls back to SA. */
export function detectCountryFromHeaders(headers: Headers): CountryCode {
  const ipCountry =
    headers.get("cf-ipcountry") ??
    headers.get("CF-IPCountry") ??
    headers.get("x-vercel-ip-country");
  if (ipCountry && ipCountry !== "XX" && isValidCountry(ipCountry.toUpperCase())) {
    return ipCountry.toUpperCase() as CountryCode;
  }

  const fromLang = countryFromAcceptLanguage(headers.get("accept-language"));
  if (fromLang) return fromLang;

  const fromTz = countryFromTimezone(headers.get("x-timezone"));
  if (fromTz) return fromTz;

  return "SA";
}

/** Client-side fallback when headers are unavailable. */
export function detectCountryFromBrowser(): CountryCode {
  try {
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
    const fromTz = countryFromTimezone(tz);
    if (fromTz) return fromTz;
  } catch {
    /* ignore */
  }
  if (typeof navigator !== "undefined") {
    const fromLang = countryFromAcceptLanguage(navigator.language);
    if (fromLang) return fromLang;
    const region = navigator.language?.split("-")[1]?.toUpperCase();
    if (isValidCountry(region)) return region;
  }
  return "SA";
}
