# Graph Report - web\src  (2026-06-16)

## Corpus Check
- 391 files · ~134,974 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 1898 nodes · 7146 edges · 77 communities (74 shown, 3 thin omitted)
- Extraction: 96% EXTRACTED · 4% INFERRED · 0% AMBIGUOUS · INFERRED: 297 edges (avg confidence: 0.8)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `77bb9802`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- [[_COMMUNITY_Community 0|Community 0]]
- [[_COMMUNITY_Community 1|Community 1]]
- [[_COMMUNITY_Community 2|Community 2]]
- [[_COMMUNITY_Community 3|Community 3]]
- [[_COMMUNITY_Community 4|Community 4]]
- [[_COMMUNITY_Community 5|Community 5]]
- [[_COMMUNITY_Community 6|Community 6]]
- [[_COMMUNITY_Community 7|Community 7]]
- [[_COMMUNITY_Community 8|Community 8]]
- [[_COMMUNITY_Community 9|Community 9]]
- [[_COMMUNITY_Community 10|Community 10]]
- [[_COMMUNITY_Community 11|Community 11]]
- [[_COMMUNITY_Community 12|Community 12]]
- [[_COMMUNITY_Community 13|Community 13]]
- [[_COMMUNITY_Community 14|Community 14]]
- [[_COMMUNITY_Community 15|Community 15]]
- [[_COMMUNITY_Community 16|Community 16]]
- [[_COMMUNITY_Community 17|Community 17]]
- [[_COMMUNITY_Community 18|Community 18]]
- [[_COMMUNITY_Community 19|Community 19]]
- [[_COMMUNITY_Community 20|Community 20]]
- [[_COMMUNITY_Community 21|Community 21]]
- [[_COMMUNITY_Community 22|Community 22]]
- [[_COMMUNITY_Community 23|Community 23]]
- [[_COMMUNITY_Community 24|Community 24]]
- [[_COMMUNITY_Community 25|Community 25]]
- [[_COMMUNITY_Community 26|Community 26]]
- [[_COMMUNITY_Community 27|Community 27]]
- [[_COMMUNITY_Community 28|Community 28]]
- [[_COMMUNITY_Community 29|Community 29]]
- [[_COMMUNITY_Community 30|Community 30]]
- [[_COMMUNITY_Community 31|Community 31]]
- [[_COMMUNITY_Community 32|Community 32]]
- [[_COMMUNITY_Community 33|Community 33]]
- [[_COMMUNITY_Community 34|Community 34]]
- [[_COMMUNITY_Community 35|Community 35]]
- [[_COMMUNITY_Community 36|Community 36]]
- [[_COMMUNITY_Community 37|Community 37]]
- [[_COMMUNITY_Community 38|Community 38]]
- [[_COMMUNITY_Community 39|Community 39]]
- [[_COMMUNITY_Community 40|Community 40]]
- [[_COMMUNITY_Community 41|Community 41]]
- [[_COMMUNITY_Community 42|Community 42]]
- [[_COMMUNITY_Community 43|Community 43]]
- [[_COMMUNITY_Community 44|Community 44]]
- [[_COMMUNITY_Community 45|Community 45]]
- [[_COMMUNITY_Community 47|Community 47]]
- [[_COMMUNITY_Community 49|Community 49]]
- [[_COMMUNITY_Community 50|Community 50]]
- [[_COMMUNITY_Community 51|Community 51]]
- [[_COMMUNITY_Community 52|Community 52]]
- [[_COMMUNITY_Community 53|Community 53]]
- [[_COMMUNITY_Community 54|Community 54]]
- [[_COMMUNITY_Community 55|Community 55]]
- [[_COMMUNITY_Community 56|Community 56]]
- [[_COMMUNITY_Community 57|Community 57]]
- [[_COMMUNITY_Community 58|Community 58]]
- [[_COMMUNITY_Community 59|Community 59]]
- [[_COMMUNITY_Community 60|Community 60]]
- [[_COMMUNITY_Community 61|Community 61]]
- [[_COMMUNITY_Community 62|Community 62]]
- [[_COMMUNITY_Community 63|Community 63]]
- [[_COMMUNITY_Community 64|Community 64]]
- [[_COMMUNITY_Community 65|Community 65]]
- [[_COMMUNITY_Community 66|Community 66]]
- [[_COMMUNITY_Community 67|Community 67]]
- [[_COMMUNITY_Community 68|Community 68]]
- [[_COMMUNITY_Community 69|Community 69]]
- [[_COMMUNITY_Community 70|Community 70]]
- [[_COMMUNITY_Community 71|Community 71]]
- [[_COMMUNITY_Community 72|Community 72]]
- [[_COMMUNITY_Community 73|Community 73]]
- [[_COMMUNITY_Community 74|Community 74]]
- [[_COMMUNITY_Community 75|Community 75]]
- [[_COMMUNITY_Community 76|Community 76]]

## God Nodes (most connected - your core abstractions)
1. `handleError()` - 235 edges
2. `cn()` - 116 edges
3. `requireAgentAuth()` - 100 edges
4. `getSettings()` - 100 edges
5. `requireUser()` - 95 edges
6. `resolveAgentUserId()` - 90 edges
7. `execute()` - 56 edges
8. `logAudit()` - 56 edges
9. `getCurrentUser()` - 49 edges
10. `getLimits()` - 46 edges

## Surprising Connections (you probably didn't know these)
- `AgentConsoleRedirect()` --calls--> `getCurrentUser()`  [INFERRED]
  app/agent/console/page.tsx → lib/auth.ts
- `AdminUsersRedirect()` --calls--> `isSingleUserMode()`  [EXTRACTED]
  app/admin/users/page.tsx → lib/agentAuth.ts
- `AgentRedirect()` --calls--> `getCurrentUser()`  [EXTRACTED]
  app/agent/page.tsx → lib/auth.ts
- `GET()` --calls--> `handleError()`  [INFERRED]
  app/api/admin/binance-capture/route.ts → lib/api.ts
- `GET()` --calls--> `requireAdmin()`  [INFERRED]
  app/api/admin/binance-capture/route.ts → lib/api.ts

## Import Cycles
- 3-file cycle: `lib/db.ts -> lib/db/index.ts -> lib/env.ts -> lib/db.ts`
- 4-file cycle: `lib/db.ts -> lib/db/index.ts -> lib/db/sqlite.ts -> lib/env.ts -> lib/db.ts`

## Communities (77 total, 3 thin omitted)

### Community 0 - "Community 0"
Cohesion: 0.13
Nodes (34): GET(), htmlPage(), GET(), schema, GET(), schema, getBrokerAdapter(), POST() (+26 more)

### Community 1 - "Community 1"
Cohesion: 0.13
Nodes (11): CommitteeFeed(), HeatmapCell, HeatmapGrid(), MacroTicker(), MemoryHighlights(), FlowSignal, WhaleBubbles(), MarketContext (+3 more)

### Community 2 - "Community 2"
Cohesion: 0.18
Nodes (27): deliverSignal(), DeliveryGateResult, DeliveryReason, dispatchAlert(), evaluateDelivery(), isTradeAlert(), REASON_AR, debugSessionLog() (+19 more)

### Community 3 - "Community 3"
Cohesion: 0.29
Nodes (12): POST(), schema, validateChartDrawings(), committeeSummaryTelegram(), canUseMt5ChartCapture(), mt5ChartUrl(), queueMt5ChartCapture(), saveRecommendation() (+4 more)

### Community 4 - "Community 4"
Cohesion: 0.05
Nodes (52): ConsoleAccountPage(), ForexBackendMode, DashboardClient(), STATUS_LABEL, LABELS, PhoneInput(), PRIORITY, ALERT_TYPE_LABEL (+44 more)

### Community 5 - "Community 5"
Cohesion: 0.18
Nodes (13): GET(), AgentModelStatus, buildFallbackRefs(), CROSS_FALLBACK_CANDIDATES, FALLBACK_PROVIDER_ORDER, getAgentModelStatus(), isAllowedModelRef(), PROVIDER_BASE_URL (+5 more)

### Community 6 - "Community 6"
Cohesion: 0.14
Nodes (29): DELETE(), GET(), PATCH(), imageSchema, POST(), schema, execute(), Params (+21 more)

### Community 7 - "Community 7"
Cohesion: 0.14
Nodes (23): AnthropicResponse, Message, StreamHandlers, SystemPromptInput, ToolDef, compatModelId(), CompatProvider, DEFAULT_MODEL (+15 more)

### Community 8 - "Community 8"
Cohesion: 0.19
Nodes (23): POST(), schema, POST(), schema, GET(), POST(), GET(), getAccountSummary() (+15 more)

### Community 9 - "Community 9"
Cohesion: 0.06
Nodes (46): AppShell(), ChatClient(), ChatMessage, MessageBubble(), RecCard(), ChatSquareClient(), STATUS_AR, STATUS_CLASS (+38 more)

### Community 10 - "Community 10"
Cohesion: 0.11
Nodes (27): arcPath(), AssetDistributionChart(), polarToCartesian(), SLICE_COLORS, InteractivePerformanceChart(), PeriodSelector(), ReportsClient(), DashboardAnalytics() (+19 more)

### Community 11 - "Community 11"
Cohesion: 0.24
Nodes (14): GET(), ConsoleOverviewPage(), ForexConnectionView, getForexConnectionView(), getBinanceAccountMeta(), getSettings(), listIntents(), listRecommendations() (+6 more)

### Community 12 - "Community 12"
Cohesion: 0.36
Nodes (6): TelegramLoginButton(), isSingleUserMode(), getTelegramLoginConfig(), LoginPage(), RegisterPage(), SignupPage()

### Community 13 - "Community 13"
Cohesion: 0.14
Nodes (30): BinanceEnv, FuturesPosition, buildConsoleActiveTrades(), loadIntentSlTp(), mapAichartBase(), mapBinanceFuturesRow(), mapMt5Row(), platformLabel() (+22 more)

### Community 14 - "Community 14"
Cohesion: 0.13
Nodes (11): AdminOverview(), MasterKillCard(), ActiveTradesTable(), BridgeOverviewClient(), ConnectionStatus, StatusChip(), StatusChipTone, TONE (+3 more)

### Community 15 - "Community 15"
Cohesion: 0.19
Nodes (19): binanceFuturesAdapter, roundToStep(), cancelAllFuturesOrders(), cancelFuturesOrder(), FUTURES_BASE_URLS, FuturesOpenOrder, FuturesPlacedOrder, futuresRequest() (+11 more)

### Community 16 - "Community 16"
Cohesion: 0.13
Nodes (28): POST(), POST(), schema, GET(), getPublicAppUrl(), BinanceCaptureConfig, BinanceCaptureMarket, binanceChartUrl() (+20 more)

### Community 17 - "Community 17"
Cohesion: 0.10
Nodes (20): botCommands, menuActions, crypto, demo, forex, iadadat, live, qaima (+12 more)

### Community 18 - "Community 18"
Cohesion: 0.11
Nodes (40): accountFooterLines(), AccountProfile, accountTypeAr(), buildAccountProfile(), platformLabel(), appBaseUrl(), ApprovalKind, ApprovalRequestInput (+32 more)

### Community 19 - "Community 19"
Cohesion: 0.09
Nodes (21): AgentRedirect(), BEGINNER_STEPS, EXPERT_STEPS, AgentConsoleRedirect(), AgentStatus, AgentStatusBar(), MODE_LABEL, pulseState() (+13 more)

### Community 20 - "Community 20"
Cohesion: 0.19
Nodes (15): ensureDb(), getDbInfo(), initDb(), insertReturningId(), isPostgresReady(), queryOne(), setBootstrapCache(), pgQueryOne() (+7 more)

### Community 21 - "Community 21"
Cohesion: 0.09
Nodes (49): DELETE(), DELETE(), POST(), GET(), GET(), schema, POST(), schema (+41 more)

### Community 22 - "Community 22"
Cohesion: 0.13
Nodes (15): AdminLayout(), ChatRedirect(), CommandRedirect(), ConsoleLayout(), metadata, clearSession(), createSessionToken(), getCurrentUser() (+7 more)

### Community 23 - "Community 23"
Cohesion: 0.15
Nodes (15): AgentPlanMode, ANALYSIS_PLAN_TEMPLATE, applyProgress(), cloneTasks(), flattenSubtaskKeys(), getPlanTemplate(), PlanStatus, PlanSubtask (+7 more)

### Community 24 - "Community 24"
Cohesion: 0.22
Nodes (18): POST(), schema, GET(), POST(), rawSchema, schema, SL_LABEL, STYLE_LABEL (+10 more)

### Community 25 - "Community 25"
Cohesion: 0.06
Nodes (75): DELETE(), POST(), GET(), forexBrokerKind(), getForexBackend(), GET(), eaForexInstruments(), GET() (+67 more)

### Community 26 - "Community 26"
Cohesion: 0.07
Nodes (37): BRIDGE_NAV_MORE, BRIDGE_NAV_PRIMARY, BRIDGE_NAV_SECONDARY, bridgeNavLabel(), BridgeShell(), DEFAULT_SYMBOL, Instrument, MarketClient() (+29 more)

### Community 27 - "Community 27"
Cohesion: 0.14
Nodes (23): DELETE(), PATCH(), schema, computeAccessExpiresAt(), ADMIN_LIMIT_FIELDS, deleteUser(), ensureUserDefaults(), getAdminPlatformStats() (+15 more)

### Community 28 - "Community 28"
Cohesion: 0.29
Nodes (17): modelRefFromPlatform(), getAnthropicModel(), listAnthropicModels(), compatTarget(), getActiveModel(), getProviderApiKey(), providerKeyField(), listOpenAIChatModels() (+9 more)

### Community 29 - "Community 29"
Cohesion: 0.13
Nodes (15): AccountSummary, ApiRestrictions, BASE_URLS, BinanceBalance, Candle, OcoOrderListStatus, PlacedOcoOrder, PlacedOrder (+7 more)

### Community 30 - "Community 30"
Cohesion: 0.10
Nodes (32): OVERLAY_LABELS, Props, LivePriceTick, applyChartDrawings(), ApplyDrawingsResult, collectDrawingMarkers(), FIB_RATIOS, fibLevels() (+24 more)

### Community 31 - "Community 31"
Cohesion: 0.09
Nodes (38): POST(), schema, GET(), GET(), POST(), schema, HeartbeatBody, POST() (+30 more)

### Community 32 - "Community 32"
Cohesion: 0.16
Nodes (18): POST(), POST(), schema, POST(), schema, POST(), POST(), schema (+10 more)

### Community 33 - "Community 33"
Cohesion: 0.10
Nodes (22): LandingAccess(), LANDING, LandingCta(), LandingFaq(), LandingFeatures(), LandingFooter(), LandingHero(), LandingHowItWorks() (+14 more)

### Community 34 - "Community 34"
Cohesion: 0.24
Nodes (16): binanceAdapter, eaAdapter, computeForexLots(), LotSizingResult, roundToStep(), metaApiAdapter, mt5LocalAdapter, BrokerAdapter (+8 more)

### Community 35 - "Community 35"
Cohesion: 0.20
Nodes (18): POST(), schema, isSymbolAllowed(), levelProximity(), OpportunityCandidate, ProximityHit, ProximityKind, scanForexSymbol() (+10 more)

### Community 36 - "Community 36"
Cohesion: 0.12
Nodes (30): CHART_ANALYZE_TOOL_NAMES, CHART_ANALYZE_TOOLS, runAgent(), TOOLS, describeToolUse(), AnthropicModelInfo, buildSystemBlocks(), CacheControl (+22 more)

### Community 37 - "Community 37"
Cohesion: 0.09
Nodes (29): DELETE(), GET(), PATCH(), patchSchema, DELETE(), GET(), POST(), GET() (+21 more)

### Community 38 - "Community 38"
Cohesion: 0.23
Nodes (11): POST(), schema, OpportunityScanCard(), WaitingRoom(), INTERVAL_GROUPS, INTERVAL_SET, MARKET_INTERVALS, MarketInterval (+3 more)

### Community 39 - "Community 39"
Cohesion: 0.18
Nodes (18): decryptSecret(), encryptSecret(), getKey(), maskKey(), cache, clearPlatformConfigCache(), ConfigFieldMeta, ConfigStatusItem (+10 more)

### Community 40 - "Community 40"
Cohesion: 0.25
Nodes (12): createEmbedding(), isEmbeddingConfigured(), openAiKey(), synthesizeSpeech(), getPlatformValueAsync(), extractText(), outcomeFromPnl(), parsePostMortemJson() (+4 more)

### Community 41 - "Community 41"
Cohesion: 0.12
Nodes (26): POST(), Home(), AwaitingApprovalPage(), POST(), schema, AwaitingApprovalClient(), COPY, ApiError (+18 more)

### Community 42 - "Community 42"
Cohesion: 0.16
Nodes (29): GET(), GET(), AgentResult, DeliveryResult, getKlines(), parseChartDrawingsJson(), ChartOverlay, ChartOverlayType (+21 more)

### Community 47 - "Community 47"
Cohesion: 0.29
Nodes (11): loadPlatformConfigRows(), getSqliteDb(), initDb(), initSqlite(), migrate(), seedAdminSqlite(), sqliteExecute(), sqliteLoadBootstrapKeys() (+3 more)

### Community 49 - "Community 49"
Cohesion: 0.17
Nodes (21): TradingCard(), GET(), TickerRow, allowedAssetsLabel(), cleanList(), FOREX_SCAN_FALLBACK, isOpenAssetsPolicy(), listIsOpen() (+13 more)

### Community 50 - "Community 50"
Cohesion: 0.28
Nodes (13): POST(), captureKeyForRecommendation(), dataRoot(), eaChartPngPath(), getPendingChartCapture(), isEaChartFileReady(), isEaOnline(), Mt5ChartCaptureInput (+5 more)

### Community 51 - "Community 51"
Cohesion: 0.12
Nodes (12): AdminSystemPanel(), HealthPayload, StatusPill(), AdminUsagePanel(), ClaudeUsageRow, AuditRow, PlatformSection(), ProfileProps (+4 more)

### Community 52 - "Community 52"
Cohesion: 0.17
Nodes (15): formatMt5TradeError(), MT5_RETCODE_LEGEND, parseMt5Retcode(), POST(), schema, EaCommandAckResult, sleep(), waitForEaCommandAck() (+7 more)

### Community 53 - "Community 53"
Cohesion: 0.05
Nodes (62): CHAINS, COMMANDS, UA, CHAINS, COMMANDS, UA, GET(), GET() (+54 more)

### Community 54 - "Community 54"
Cohesion: 0.15
Nodes (29): POST(), livePrice(), getOcoOrderList(), getPrice(), getSymbolFilters(), roundToTick(), getFuturesOrder(), CronPostScanResult (+21 more)

### Community 55 - "Community 55"
Cohesion: 0.47
Nodes (8): checkSlTpProximity(), collectTradeWatchAlerts(), forexMidPrice(), intentStopsForTrade(), TradeWatchAlert, watchAichartOpenTrades(), watchFuturesLiquidationProximity(), watchMt5Positions()

### Community 56 - "Community 56"
Cohesion: 0.14
Nodes (12): cairo, fraunces, inter, jetbrainsMono, metadata, getSystemTheme(), ResolvedTheme, resolveTheme() (+4 more)

### Community 57 - "Community 57"
Cohesion: 0.21
Nodes (14): GET(), getFuturesOpenOrders(), getFuturesPositions(), getBinanceLiveQuotes(), EaLiveEvent, EaLiveQuote, eventsByUser, getEaLiveQuote() (+6 more)

### Community 58 - "Community 58"
Cohesion: 0.20
Nodes (19): bootstrapCache, transaction(), getPool(), initPg(), mapRows(), migratePg(), pgExecute(), pgInsertReturningId() (+11 more)

### Community 59 - "Community 59"
Cohesion: 0.43
Nodes (6): AgentWakeEvent, EVENT_INSTRUCTIONS, WakeAgentOptions, wakeAgentViaTelegram(), wakeAuditAction(), wasRecentlyWoken()

### Community 60 - "Community 60"
Cohesion: 0.18
Nodes (9): agentCommandFromCallback(), BotCommandDef, CMD_CALLBACK_MAP, MENU_ACTIONS, postAnalysisButtons(), replyLabelToAgentCommand(), resolveUserMenuInput(), slashCommandToAgentAction() (+1 more)

### Community 61 - "Community 61"
Cohesion: 0.23
Nodes (13): POST(), verifyCronSecret(), candidateDetail(), forexScanReady(), MonitorCycleEvent, MonitorCycleResult, runMonitorCycle(), scanMarketForUser() (+5 more)

### Community 62 - "Community 62"
Cohesion: 0.29
Nodes (13): GET(), patchSchema, PUT(), requireAdmin(), audioFormatFromMime(), audioMimeFromFormat(), geminiApiKey(), isGeminiChatModelId() (+5 more)

### Community 63 - "Community 63"
Cohesion: 0.26
Nodes (10): ALLOWED_IMAGE_TYPES, buildUserMessageContent(), ChatImageMediaType, fileToChatImage(), isAllowedImageType(), parseImageFromMetadata(), validateChatImage(), INJECTION_PATTERNS (+2 more)

### Community 64 - "Community 64"
Cohesion: 0.33
Nodes (10): getDbBackend(), cosineSimilarity(), filterBySymbolFallback(), insertTradeLesson(), InsertTradeLessonInput, parseEmbedding(), searchSimilarLessons(), SearchSimilarLessonsQuery (+2 more)

### Community 65 - "Community 65"
Cohesion: 0.12
Nodes (14): AdminUsersTable(), TableMode, ConsoleConnectPage(), loadConsoleSettingsProps(), AdminUserView, listAuditLogs(), listUsersForAdmin(), ConsolePlatformPage() (+6 more)

### Community 66 - "Community 66"
Cohesion: 0.27
Nodes (4): ADMIN_ACTION_LABELS, ADMIN_NAV, AdminSecurityPanel(), AuditRow

### Community 67 - "Community 67"
Cohesion: 0.53
Nodes (5): isValidStop(), minStopDistance(), NormalizedMt5Stops, normalizeMt5Stops(), roundPrice()

### Community 68 - "Community 68"
Cohesion: 0.21
Nodes (12): DispatchAlertOptions, ChartDrawing, drawingPriceBounds(), CheckInput, intentAgeMinutes(), OpportunityCheck, OpportunityVerdict, validateOpportunity() (+4 more)

### Community 69 - "Community 69"
Cohesion: 0.39
Nodes (8): marketAssetsJson(), parseMarketAssets(), serializeMarketAssets(), setMarketAssets(), setWatchlist(), assetList, PUT(), schema

### Community 70 - "Community 70"
Cohesion: 0.39
Nodes (6): Window, isTelegramConfiguredAsync(), TelegramLoginPayload, verifyTelegramLogin(), POST(), schema

### Community 71 - "Community 71"
Cohesion: 0.38
Nodes (9): parseEaSymbolSpecs(), CRYPTO_ALIASES, findByForexCanonical(), findCaseInsensitive(), forexCanonicalKey(), formatEaSymbolHint(), getEaSymbolList(), getEaSymbolSet() (+1 more)

### Community 72 - "Community 72"
Cohesion: 0.22
Nodes (6): AdminKeysPanel(), ConfigField, GROUPS, StatusBadge(), ClaudeModelOption, ClaudeModelPicker()

### Community 73 - "Community 73"
Cohesion: 0.42
Nodes (6): POST(), isAgentWakeEnabled(), buildDailySummary(), sendDailySummary(), listUsersForDailySummary(), sendMessage()

### Community 74 - "Community 74"
Cohesion: 0.43
Nodes (6): createSchema, GET(), query(), listArchivedConversations(), listConversations(), listAgentAuditLogs()

### Community 75 - "Community 75"
Cohesion: 0.53
Nodes (4): getBootstrapFromCache(), getAppSecret(), getEncryptionKey(), readBootstrapKey()

### Community 76 - "Community 76"
Cohesion: 0.50
Nodes (4): ExecutionEnv, ProposedTrade, RiskContext, RiskDecision

## Knowledge Gaps
- **309 isolated node(s):** `providerSchema`, `bodySchema`, `NormalizedModel`, `patchSchema`, `schema` (+304 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **3 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `handleError()` connect `Community 21` to `Community 0`, `Community 2`, `Community 3`, `Community 5`, `Community 6`, `Community 8`, `Community 11`, `Community 13`, `Community 16`, `Community 20`, `Community 24`, `Community 25`, `Community 27`, `Community 28`, `Community 31`, `Community 32`, `Community 35`, `Community 37`, `Community 38`, `Community 40`, `Community 41`, `Community 42`, `Community 49`, `Community 50`, `Community 52`, `Community 53`, `Community 54`, `Community 57`, `Community 62`, `Community 69`, `Community 70`, `Community 74`?**
  _High betweenness centrality (0.102) - this node is a cross-community bridge._
- **Why does `cn()` connect `Community 26` to `Community 65`, `Community 66`, `Community 1`, `Community 4`, `Community 33`, `Community 72`, `Community 9`, `Community 10`, `Community 14`, `Community 51`, `Community 19`, `Community 23`, `Community 30`?**
  _High betweenness centrality (0.058) - this node is a cross-community bridge._
- **Why does `getSettings()` connect `Community 11` to `Community 0`, `Community 2`, `Community 3`, `Community 6`, `Community 8`, `Community 13`, `Community 18`, `Community 21`, `Community 22`, `Community 24`, `Community 25`, `Community 27`, `Community 31`, `Community 32`, `Community 35`, `Community 36`, `Community 37`, `Community 38`, `Community 41`, `Community 42`, `Community 49`, `Community 53`, `Community 54`, `Community 55`, `Community 61`, `Community 65`, `Community 69`, `Community 73`?**
  _High betweenness centrality (0.030) - this node is a cross-community bridge._
- **Are the 41 inferred relationships involving `handleError()` (e.g. with `POST()` and `POST()`) actually correct?**
  _`handleError()` has 41 INFERRED edges - model-reasoned connections that need verification._
- **Are the 17 inferred relationships involving `requireAgentAuth()` (e.g. with `POST()` and `DELETE()`) actually correct?**
  _`requireAgentAuth()` has 17 INFERRED edges - model-reasoned connections that need verification._
- **Are the 13 inferred relationships involving `getSettings()` (e.g. with `GET()` and `POST()`) actually correct?**
  _`getSettings()` has 13 INFERRED edges - model-reasoned connections that need verification._
- **Are the 18 inferred relationships involving `requireUser()` (e.g. with `POST()` and `DELETE()`) actually correct?**
  _`requireUser()` has 18 INFERRED edges - model-reasoned connections that need verification._